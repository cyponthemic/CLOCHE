# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------


#
# Delete any existing table `clocommentmeta`
#

DROP TABLE IF EXISTS `clocommentmeta`;


#
# Table structure of table `clocommentmeta`
#

CREATE TABLE `clocommentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table clocommentmeta (0 records)
#

#
# End of data contents of table clocommentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocomments`
# --------------------------------------------------------


#
# Delete any existing table `clocomments`
#

DROP TABLE IF EXISTS `clocomments`;


#
# Table structure of table `clocomments`
#

CREATE TABLE `clocomments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table clocomments (1 records)
#
 
INSERT INTO `clocomments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-07-17 02:28:19', '2014-07-17 02:28:19', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table clocomments
# --------------------------------------------------------

# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocomments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clolinks`
# --------------------------------------------------------


#
# Delete any existing table `clolinks`
#

DROP TABLE IF EXISTS `clolinks`;


#
# Table structure of table `clolinks`
#

CREATE TABLE `clolinks` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table clolinks (0 records)
#

#
# End of data contents of table clolinks
# --------------------------------------------------------

# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocomments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clolinks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clooptions`
# --------------------------------------------------------


#
# Delete any existing table `clooptions`
#

DROP TABLE IF EXISTS `clooptions`;


#
# Table structure of table `clooptions`
#

CREATE TABLE `clooptions` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=utf8 ;

#
# Data contents of table clooptions (142 records)
#
 
INSERT INTO `clooptions` VALUES (1, 'siteurl', 'http://localhost:8888/CLOCHE', 'yes') ; 
INSERT INTO `clooptions` VALUES (2, 'blogname', 'CLOCHE', 'yes') ; 
INSERT INTO `clooptions` VALUES (3, 'blogdescription', 'Just another WordPress site', 'yes') ; 
INSERT INTO `clooptions` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (5, 'admin_email', 'alex.chavet@gmail.com', 'yes') ; 
INSERT INTO `clooptions` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `clooptions` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `clooptions` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `clooptions` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `clooptions` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `clooptions` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `clooptions` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `clooptions` VALUES (20, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `clooptions` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `clooptions` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `clooptions` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `clooptions` VALUES (25, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (26, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (27, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `clooptions` VALUES (28, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (29, 'hack_file', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (30, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `clooptions` VALUES (31, 'moderation_keys', '', 'no') ; 
INSERT INTO `clooptions` VALUES (32, 'active_plugins', 'a:1:{i:0;s:39:"backup-with-restore/backupwordpress.php";}', 'yes') ; 
INSERT INTO `clooptions` VALUES (33, 'home', 'http://localhost:8888/CLOCHE', 'yes') ; 
INSERT INTO `clooptions` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `clooptions` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `clooptions` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `clooptions` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `clooptions` VALUES (41, 'template', 'cornerstone', 'yes') ; 
INSERT INTO `clooptions` VALUES (42, 'stylesheet', 'cloche', 'yes') ; 
INSERT INTO `clooptions` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `clooptions` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `clooptions` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `clooptions` VALUES (49, 'db_version', '27916', 'yes') ; 
INSERT INTO `clooptions` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `clooptions` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `clooptions` VALUES (54, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `clooptions` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `clooptions` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `clooptions` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `clooptions` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `clooptions` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `clooptions` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `clooptions` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `clooptions` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `clooptions` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `clooptions` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `clooptions` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `clooptions` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `clooptions` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `clooptions` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `clooptions` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `clooptions` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `clooptions` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `clooptions` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `clooptions` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `clooptions` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (80, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (82, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `clooptions` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `clooptions` VALUES (84, 'page_for_posts', '5', 'yes') ; 
INSERT INTO `clooptions` VALUES (85, 'page_on_front', '2', 'yes') ; 
INSERT INTO `clooptions` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `clooptions` VALUES (88, 'initial_db_version', '27916', 'yes') ; 
INSERT INTO `clooptions` VALUES (89, 'clouser_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `clooptions` VALUES (90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (95, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:13:"right_sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:14:"footer_sidebar";a:0:{}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (96, 'cron', 'a:6:{i:1405669260;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1405670454;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1405671776;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1405693725;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1405724400;a:1:{s:19:"hmbkp_schedule_hook";a:2:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (98, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.1";s:7:"version";s:5:"3.9.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1405660930;s:15:"version_checked";s:5:"3.9.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `clooptions` VALUES (103, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1405660931;s:7:"checked";a:5:{s:6:"cloche";s:3:"1.0";s:11:"cornerstone";s:5:"3.2.1";s:14:"twentyfourteen";s:3:"1.1";s:14:"twentythirteen";s:3:"1.2";s:12:"twentytwelve";s:3:"1.4";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `clooptions` VALUES (112, '_site_transient_timeout_browser_ca5ba42c15733d13e46d15eccaa92dae', '1406188855', 'yes') ; 
INSERT INTO `clooptions` VALUES (113, '_site_transient_browser_ca5ba42c15733d13e46d15eccaa92dae', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"36.0.1985.125";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (116, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `clooptions` VALUES (129, '_transient_timeout_plugin_slugs', '1405747999', 'no') ; 
INSERT INTO `clooptions` VALUES (130, '_transient_plugin_slugs', 'a:3:{i:0;s:19:"akismet/akismet.php";i:1;s:9:"hello.php";i:2;s:39:"backup-with-restore/backupwordpress.php";}', 'no') ; 
INSERT INTO `clooptions` VALUES (134, 'current_theme', 'Cloche', 'yes') ; 
INSERT INTO `clooptions` VALUES (135, 'theme_mods_JointsWP-CSS-master', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1405585249;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:8:"sidebar1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"offcanvas";a:0:{}}}}', 'yes') ; 
INSERT INTO `clooptions` VALUES (136, 'theme_switched', '', 'yes') ; 
INSERT INTO `clooptions` VALUES (137, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1405585270;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `clooptions` VALUES (138, 'theme_mods_cloche', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:3:{s:17:"header-menu-right";i:2;s:11:"footer-menu";i:2;s:16:"header-menu-left";i:0;}}', 'yes') ; 
INSERT INTO `clooptions` VALUES (141, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `clooptions` VALUES (142, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (143, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (144, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (145, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (146, 'rewrite_rules', 'a:82:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:33:"orbit/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"orbit/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"orbit/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"orbit/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"orbit/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"orbit/([^/]+)/trackback/?$";s:32:"index.php?orbit=$matches[1]&tb=1";s:34:"orbit/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?orbit=$matches[1]&paged=$matches[2]";s:41:"orbit/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?orbit=$matches[1]&cpage=$matches[2]";s:26:"orbit/([^/]+)(/[0-9]+)?/?$";s:44:"index.php?orbit=$matches[1]&page=$matches[2]";s:22:"orbit/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"orbit/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"orbit/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"orbit/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"orbit/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `clooptions` VALUES (156, '_site_transient_timeout_theme_roots', '1405662519', 'yes') ; 
INSERT INTO `clooptions` VALUES (157, '_site_transient_theme_roots', 'a:5:{s:6:"cloche";s:7:"/themes";s:11:"cornerstone";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `clooptions` VALUES (159, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1405703946', 'no') ; 
INSERT INTO `clooptions` VALUES (160, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 10:27:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:42:"http://wordpress.org/?v=4.0-beta1-20140717";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 10:17:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3248";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"WordPress 4.0 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4025:"<p>WordPress 4.0 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta1.zip">download the beta here</a> (zip).</p>
<p>4.0 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Previews of <a href="http://codex.wordpress.org/Embeds">embedding via URLs</a></strong> in the visual editor and the &#8220;Insert from URL&#8221; tab in the media modal. Try pasting a URL (such as a <a href="http://wordpress.tv/">WordPress.tv</a> or YouTube video) onto its own line in the visual editor. (<a href="https://core.trac.wordpress.org/ticket/28195">#28195</a>, <a href="https://core.trac.wordpress.org/ticket/15490">#15490</a>)</li>
<li>The <strong>Media Library</strong> now has a &#8220;grid&#8221; view in addition to the existing list view. Clicking on an item takes you into a modal where you can see a larger preview and edit information about that attachment, and you can navigate between items right from the modal without closing it. (<a href="https://core.trac.wordpress.org/ticket/24716">#24716</a>)</li>
<li>We&#8217;re freshening up the <strong>plugin install experience</strong>. You&#8217;ll see some early visual changes as well as more information when searching for plugins and viewing details. (<a href="https://core.trac.wordpress.org/ticket/28785">#28785</a>, <a href="https://core.trac.wordpress.org/ticket/27440">#27440</a>)</li>
<li><strong>Selecting a language</strong> when you run the installation process. (<a href="https://core.trac.wordpress.org/ticket/28577">#28577</a>)</li>
<li>The <strong>editor</strong> intelligently resizes and its top and bottom bars pin when needed. Browsers don&#8217;t like to agree on where to put things like cursors, so if you find a bug here, please also let us know your browser and operating system. (<a href="https://core.trac.wordpress.org/ticket/28328">#28328</a>)</li>
<li>We&#8217;ve made some improvements to how your keyboard and cursor interact with <strong>TinyMCE views</strong> such as the gallery preview. Much like the editor resizing and scrolling improvements, knowing about your setup is particularly important for bug reports here. (<a href="https://core.trac.wordpress.org/ticket/28595">#28595</a>)</li>
<li><strong>Widgets in the Customizer</strong> are now loaded in a separate panel. (<a href="https://core.trac.wordpress.org/ticket/27406">#27406</a>)</li>
<li>We&#8217;ve also made some changes to some <strong>formatting</strong> functions, so if you see quotes curling in the wrong direction, please file a bug report.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.0">everything we’ve fixed</a> so far.</p>
<p><strong>Developers:</strong> Never fear, we haven&#8217;t forgotten you. There&#8217;s plenty for you, too &#8211; more on that in upcoming posts. In the meantime, check out the <a href="http://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/#customizer-panels">API for panels in the Customizer</a>.</p>
<p>Happy testing!</p>
<p><em>Plugins, editor</em><br />
<em>Media, things in between</em><br />
<em>Please help look for bugs</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/05/wordpress-3-9-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:385:"After three weeks and more than 9 million downloads of WordPress 3.9, we&#8217;re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3077:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="http://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&amp;stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/imath">imath</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="http://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/05/wordpress-3-9-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23298:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>
<embed src="//v0.wordpress.com/player.swf?v=1.03" type="application/x-shockwave-flash" width="640" height="360" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true" flashvars="guid=sAiXhCfV&amp;isDynamicSeeking=true" title=""></embed>
<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'http://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'http://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'http://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; max-width: 100%;" class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3154-1" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=1" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="http://profiles.wordpress.org/adelval">adelval</a>, <a href="http://profiles.wordpress.org/ajay">Ajay</a>, <a href="http://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="http://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="http://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="http://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="http://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="http://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/ciantic">ciantic</a>, <a href="http://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="http://profiles.wordpress.org/dpe415">DaveE</a>, <a href="http://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="http://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="http://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="http://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="http://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/genkisan">genkisan</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="http://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="http://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="http://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jaycc">JayCC</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jesin">Jesin A</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="http://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="http://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kerikae">kerikae</a>, <a href="http://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/klihelp">klihelp</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lpointet">lpointet</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="http://profiles.wordpress.org/lkwdwrd">Luke Woodward</a>, <a href="http://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/marventus">Marventus</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/meloniq">meloniq</a>, <a href="http://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nivijah">Nivi Jah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="http://profiles.wordpress.org/olivm">olivM</a>, <a href="http://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/oso96_2000">oso96_2000</a>, <a href="http://profiles.wordpress.org/patricknami">patricknami</a>, <a href="http://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="http://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="http://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="http://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="http://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/richard2222">richard2222</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/robmiller">robmiller</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="http://profiles.wordpress.org/roothorick">roothorick</a>, <a href="http://profiles.wordpress.org/ruudjoyo">ruud@joyo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="http://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/sdasse">sdasse</a>, <a href="http://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="http://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="http://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="http://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tbrams">tbrams</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="http://profiles.wordpress.org/topquarky">topquarky</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/toru">Toru</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="http://profiles.wordpress.org/wawco">wawco</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="http://profiles.wordpress.org/xsonic">xsonic</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="http://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="http://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="http://make.wordpress.org/">Make WordPress</a> and our <a href="http://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2273:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="//wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="//make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="//make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="//make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="//make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2339:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.9 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 21:05:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3129";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"As teased earlier, the first release candidate for WordPress 3.9 is now available for testing! We hope to ship WordPress 3.9 next week, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.) To test WordPress 3.9 [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2967:"<p><a href="//wordpress.org/news/2014/04/wordpress-3-8-2/">As teased earlier</a>, the first release candidate for WordPress 3.9 is now available for testing!</p>
<p>We hope to ship WordPress 3.9 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>To test WordPress 3.9 RC1, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the work-in-progress About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="//wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="//core.trac.wordpress.org/report/5">find them here</a>.</p>
<p><strong>If you&#8217;re a plugin author</strong>, there are two important changes in particular to be aware of:</p>
<ul>
<li>TinyMCE received a major update, to version 4.0. Any editor plugins written for TinyMCE 3.x might require some updates. (If things broke, we&#8217;d like to hear about them so we can make adjustments.) For more, see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">migration guide</a> and <a href="http://www.tinymce.com/wiki.php/api4:index">API documentation</a>, and the notes on the <a href="//make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">core development blog</a>.</li>
<li>WordPress 3.9 now uses the MySQLi Improved extension for sites running PHP 5.5. Any plugins that made direct calls to <code>mysql_*</code> functions will experience some problems on these sites. For more information, see the notes on the <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">core development blog</a>.</li>
</ul>
<p>Be sure to follow along the core development blog, where we will be continuing to post <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example, read <a href="//make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/">this</a> if you are using Masonry in your theme.) And please, please update your plugin&#8217;s <em>Tested up to</em> version in the readme to 3.9 before April 16.</p>
<p><em>Release candidate<br />
This haiku&#8217;s the easy one<br />
3.9 is near</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.8.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 19:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3124";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately. This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by Jon Cave of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2272:"<p>WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by <a href="http://joncave.co.uk/">Jon Cave</a> of the WordPress security team.</p>
<p>It also contains a fix to prevent a user with the Contributor role from improperly publishing posts. Reported by <a href="http://edik.ch/">edik</a>.</p>
<p>This release also fixes nine bugs and contains three other security hardening changes:</p>
<ul>
<li>Pass along additional information when processing pingbacks to help hosts identify potentially abusive requests.</li>
<li>Fix a low-impact SQL injection by trusted users. Reported by <a href="http://www.dxw.com/">Tom Adams</a> of dxw.</li>
<li>Prevent possible cross-domain scripting through Plupload, the third-party library WordPress uses for uploading files. Reported by <a href="http://szgru.website.pl/">Szymon Gruszecki</a>.</li>
</ul>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these security issues directly to our security team. For more information on all of the changes, see the <a href="http://codex.wordpress.org/Version_3.8.2">release notes</a> or consult <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=28057&amp;stop_rev=27024">the list of changes</a>.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.8.2 within 12 hours. If you are still on WordPress 3.7.1, you will be updated to 3.7.2, which contains the same security fixes as 3.8.2. We don&#8217;t support older versions, so please update to 3.8.2 for the latest and greatest.</p>
<p>Already testing WordPress 3.9? The first release candidate is <a href="https://wordpress.org/wordpress-3.9-RC1.zip">now available</a> (zip) and it contains these security fixes. Look for a full announcement later today; we expect to release 3.9 next week.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 29 Mar 2014 13:15:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3106";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:373:"The third (and maybe last) beta of WordPress 3.9 is now available for download. Beta 3 includes more than 200 changes, including: New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out. UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2668:"<p>The third (and maybe last) beta of WordPress 3.9 is now available for download.</p>
<p>Beta 3 includes more than 200 <a href="https://core.trac.wordpress.org/log?rev=27850&amp;stop_rev=27639&amp;limit=300">changes</a>, including:</p>
<ul>
<li>New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out.</li>
<li>UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought back some of the advanced display settings for images.</li>
<li>If you want to test out audio and video playlists, the links will appear in the media manager once you&#8217;ve uploaded an audio or video file.</li>
<li>For theme developers, we&#8217;ve added HTML5 caption support (<a class="reopened ticket" title="task (blessed): HTML5 captions (reopened)" href="https://core.trac.wordpress.org/ticket/26642">#26642</a>) to match the new gallery support (<a class="closed ticket" title="enhancement: HTML5 Galleries (closed: fixed)" href="https://core.trac.wordpress.org/ticket/26697">#26697</a>).</li>
<li>The formatting function that turns straight quotes into smart quotes (among other things) underwent some changes to drastically speed it up, so let us know if you see anything weird.</li>
</ul>
<p><strong>We need your help</strong>. We&#8217;re still aiming for an April release, which means the next week will be critical for identifying and squashing bugs. If you&#8217;re just joining us, please see <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven&#8217;t tested WordPress 3.9 yet, now is the time — and be sure to update the &#8220;tested up to&#8221; version for your plugins so they&#8217;re listed as compatible with 3.9.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta3.zip">download the beta here</a> (zip).</p>
<p><em>WordPress 3.9<br />
Let&#8217;s make the date official<br />
It&#8217;s April 16</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3101";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:309:"WordPress 3.9 Beta 2 is now available for testing! We&#8217;ve made more than a hundred changes since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1901:"<p>WordPress 3.9 Beta 2 is now available for testing!</p>
<p>We&#8217;ve made more than a hundred <a href="https://core.trac.wordpress.org/log?rev=27639&amp;stop_rev=27500&amp;limit=200">changes</a> since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Rendering of embedded audio and video players directly in the visual editor.</li>
<li>Visual and functional improvements to the editor, the media manager, and theme installer.</li>
<li>Various bug fixes to TinyMCE, the software behind the visual editor.</li>
<li>Lots of fixes to widget management in the theme customizer.</li>
</ul>
<p>As always,<strong> if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta2.zip">download the beta here</a> (zip).</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Mar 2014 13:42:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3083";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"I&#8217;m excited to announce that the first beta of WordPress 3.9 is now available for testing. WordPress 3.9 is due out next month &#8212; but in order to hit that goal, we need your help testing all of the goodies we&#8217;ve added: We updated TinyMCE, the software powering the visual editor, to the latest version. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6065:"<p>I&#8217;m excited to announce that the <strong>first beta of WordPress 3.9</strong> is now available for testing.</p>
<p>WordPress 3.9 is due out next month &#8212; but in order to hit that goal, <strong>we need your help</strong> testing all of the goodies we&#8217;ve added:</p>
<ul>
<li>We updated TinyMCE, the software powering the visual editor, to the latest version. Be on the lookout for cleaner markup. Also try the new paste handling &#8212; if you paste in a block of text from Microsoft Word, for example, it will no longer come out terrible. (The &#8220;Paste from Word&#8221; button you probably never noticed has been removed.) It&#8217;s possible some plugins that added stuff to the visual editor (like a new toolbar button) no longer work, so we&#8217;d like to hear about them (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>). (And be sure to <a href="http://wordpress.org/support/">open a support thread</a> for the plugin author.)</li>
<li>We&#8217;ve added <strong>widget management to live previews</strong> (the customizer). Please test editing, adding, and rearranging widgets! (<a href="https://core.trac.wordpress.org/ticket/27112">#27112</a>) We&#8217;ve also added the ability to upload, crop, and manage header images, without needing to leave the preview. (<a href="https://core.trac.wordpress.org/ticket/21785">#21785</a>)</li>
<li>We brought 3.8&#8217;s beautiful new theme browsing experience to the <strong>theme installer</strong>. Check it out! (<a title="View ticket" href="https://core.trac.wordpress.org/ticket/27055">#27055</a>)</li>
<li><strong>Galleries</strong> now receive a live preview in the editor. Upload some photos and insert a gallery to see this in action. (<a href="https://core.trac.wordpress.org/ticket/26959">#26959</a>)</li>
<li>You can now <strong>drag-and-drop</strong> images directly onto the editor to upload them. It can be a bit finicky, so try it and help us work out the kinks. (<a href="https://core.trac.wordpress.org/ticket/19845">#19845</a>)</li>
<li>Some things got improved around <strong>editing images</strong>. It&#8217;s a lot easier to make changes to an image after you insert it into a post (<a class="closed" title="View ticket" href="https://core.trac.wordpress.org/ticket/24409">#24409</a>) and you no longer get kicked to a new window when you need to crop or rotate an image (<a href="https://core.trac.wordpress.org/ticket/21811">#21811</a>).</li>
<li>New <strong>audio/video playlists</strong>. Upload a few audio or video files to test these. (<a href="https://core.trac.wordpress.org/ticket/26631">#26631</a>)</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We&#8217;d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta1.zip">download the beta here</a> (zip).</p>
<hr />
<p><strong>DEVELOPERS!</strong> Hello! There&#8217;s lots for you, too.</p>
<p><strong>Please test your plugins and themes!</strong> There&#8217;s a lot of great stuff under the hood in 3.9 and we hope to blog a bit about them in the coming days. If you haven&#8217;t been reading the awesome <a href="http://make.wordpress.org/core/tag/week-in-core/">weekly summaries</a> on the <a href="http://make.wordpress.org/core/">main core development blog</a>, that&#8217;s a great place to start. (You should definitely follow that blog.) For now, here are some things to watch out for when testing:</p>
<ul>
<li>The <strong>load process in multisite</strong> got rewritten. If you notice any issues with your network, see <a href="https://core.trac.wordpress.org/ticket/27003">#27003</a>.</li>
<li>We now use the <strong>MySQL Improved (mysqli) database extension</strong> if you&#8217;re running a recent version of PHP (<a href="https://core.trac.wordpress.org/ticket/21663">#21663</a>). Please test your plugins and see that everything works well, and please make sure you&#8217;re not calling <code>mysql_*</code> functions directly.</li>
<li><strong>Autosave</strong> was refactored, so if you see any issues related to autosaving, heartbeat, etc., let us know (<a href="https://core.trac.wordpress.org/ticket/25272">#25272</a>).</li>
<li>Library updates, in particular Backbone 1.1 and Underscore 1.6 (<a href="https://core.trac.wordpress.org/ticket/26799">#26799</a>). Also Masonry 3 (<a href="https://core.trac.wordpress.org/ticket/25351">#25351</a>), PHPMailer (<a href="https://core.trac.wordpress.org/ticket/25560">#25560</a>), Plupload (<a href="https://core.trac.wordpress.org/ticket/25663">#25663</a>), and TinyMCE (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>).</li>
<li>TinyMCE 4.0 is a <em>major</em> update. Please see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">upgrade guide</a> and our <a href="https://core.trac.wordpress.org/ticket/24067">implementation ticket</a> for more. If you have any questions or problems, please <a href="http://wordpress.org/support/forum/alphabeta">open a thread in the support forums</a>.</li>
</ul>
<p>Happy testing!</p>
<p><em><em>Lots of improvements<br />
Little things go a long way</em><br />
Please test beta one<br />
</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Fri, 18 Jul 2014 05:19:05 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 10 Jul 2014 10:27:22 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130910180210";}', 'no') ; 
INSERT INTO `clooptions` VALUES (161, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1405703946', 'no') ; 
INSERT INTO `clooptions` VALUES (162, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1405660746', 'no') ; 
INSERT INTO `clooptions` VALUES (163, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1405703949', 'no') ; 
INSERT INTO `clooptions` VALUES (164, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: Themosis Object-Oriented Development Framework for WordPress Now in Beta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26636";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:208:"http://wptavern.com/themosis-object-oriented-development-framework-for-wordpress-now-in-beta?utm_source=rss&utm_medium=rss&utm_campaign=themosis-object-oriented-development-framework-for-wordpress-now-in-beta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4299:"<p><a href="http://www.themosis.com/" target="_blank">Themosis</a> is a new object-oriented development framework for WordPress that is currently in beta and set to be released soon. It&#8217;s aimed at developers of all skill levels but those with stronger PHP knowledge will have an easier time working with the framework.</p>
<p>Themosis was created by <a href="http://jlambe.be" target="_blank">Julien Lambé</a>, a Belgium-based application developer. His framework brings an object-oriented approach to WordPress, providing a simple and intuitive syntax. Lambé hopes that Themosis will accelerate development for users by removing repetitive tasks and creating a common code management structure to help teams work better together.</p>
<p>He describes the framework as <strong>&#8220;a mix between WordPress best practices and a typical MVC framework.&#8221;</strong> It is essentially a collection of APIs. &#8220;The Themosis framework was born to give WordPress developers the development joy found in the Laravel framework,&#8221; Lambé said. Consequently, the Routes API should be fairly easy for Laravel developers to work with.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/routes.png" rel="prettyphoto[26636]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/routes.png?resize=1025%2C598" alt="routes" class="aligncenter size-full wp-image-26649" /></a></p>
<p>The framework bundles a Views API which allows you to define layouts and sections as well as extend them. It includes a templating engine called Scout to provide helpers for building views. Scout is a fork of the <a href="http://laravel.com/docs/templates" target="_blank">Laravel Blade engine</a>.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/views.png" rel="prettyphoto[26636]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/views.png?resize=1025%2C598" alt="views" class="aligncenter size-full wp-image-26667" /></a></p>
<p>Themosis includes a <code>PostType</code> class that makes it easy to register and build custom post types. CPTs can be customized by passing arguments to the set() method, the same way you normally would with the <code><a href="http://codex.wordpress.org/Function_Reference/register_post_type" target="_blank">register_post_type()</a></code> function.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/custom-post-types.png" rel="prettyphoto[26636]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/custom-post-types.png?resize=1025%2C598" alt="custom-post-types" class="aligncenter size-full wp-image-26670" /></a></p>
<p>Lambé put together a Bookstore website project as a demonstration of how developers can build websites and web apps using the Themosis framework. The <a href="https://github.com/themosis/bookstore" target="_blank">Bookstore repository</a> serves to provide a good example of how the app&#8217;s code is structured and how to make use of the Themosis APIs.</p>
<p>If you&#8217;d like to experiment with it, the framework and its accompanying plugin and theme can be downloaded as a zip file from the <a href="http://www.themosis.com/beta/" target="_blank">Themosis Beta</a> page. In order to <a href="https://github.com/themosis/documentation/blob/master/installation.md" target="_blank">get started with the framework</a>, you will first need to install <a href="https://getcomposer.org/" target="_blank">Composer</a> (to manage Themosis dependencies) and <a href="http://wp-cli.org/" target="_blank">WP-CLI</a>.</p>
<p>Even though it&#8217;s still in beta, Themosis is already extensively <a href="https://github.com/themosis/documentation" target="_blank">documented</a>. There may be inaccuracies here and there, since the APIs are still under active development. Using the framework in production before its 1.0 release is not recommended. The beta is currently version 0.8 but Lambé <a href="https://twitter.com/Themosis/status/475220644825939969" target="_blank">announced</a> last week that he doesn&#8217;t plan to deliver a 0.9-beta version. Instead, Themosis will move straight into a stable 1.0 version. You can sign up to be notified of the launch on <a href="http://www.themosis.com/" target="_blank">Themosis.com</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Jul 2014 03:42:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WPTavern: Add Avatar Upload to BuddyPress Registration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26588";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:152:"http://wptavern.com/add-avatar-upload-to-buddypress-registration?utm_source=rss&utm_medium=rss&utm_campaign=add-avatar-upload-to-buddypress-registration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2867:"<p>Getting users to upload avatars can be a challenge for <a href="http://buddypress.org/" target="_blank">BuddyPress</a> communities. Avatars aren&#8217;t like profile fields where you can require users to complete them. The problem is that a community without many real-user avatars can be somewhat uninviting. Member directories and widgets end up looking grey and white and uninspiring. Too many default &#8220;mystery man&#8221; avatars floating around can give the impression that the social network is filled with spammers.</p>
<p>One way to encourage users to upload an avatar is to make it the first thing they see when registering for your community. <a href="http://wordpress.org/plugins/buddypress-upload-avatar-ajax/" target="_blank">BuddyPress Upload Avatar Ajax</a> is a new, albeit oddly named, plugin that adds avatar upload to the registration form. The upload button is placed even before the account details:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/upload-avatar.png" rel="prettyphoto[26588]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/upload-avatar.png?resize=500%2C369" alt="upload-avatar" class="aligncenter size-large wp-image-26594" /></a></p>
<p>New members in the process of registering can quickly upload, crop and save an avatar right on the registration page, without getting redirected.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/registration-avatar.png" rel="prettyphoto[26588]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/registration-avatar.png?resize=500%2C456" alt="registration-avatar" class="aligncenter size-large wp-image-26591" /></a></p>
<p>The user&#8217;s avatar is shown at the top as he or she continues to fill the rest of the registration fields.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/register-with-avatar.png" rel="prettyphoto[26588]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/register-with-avatar.png?resize=1025%2C1125" alt="register-with-avatar" class="aligncenter size-full wp-image-26595" /></a></p>
<p>This is a simple, proactive measure that you can add to your BuddyPress site to get more members in the door with avatars already set.  Install the plugin from WordPress.org and activate it; there are no settings to configure.</p>
<p>Don&#8217;t let your social network start to look like a ghost town that&#8217;s overrun by zombie mystery man avatars. If it&#8217;s like pulling teeth to get members to upload avatars on your site, consider adding the <a href="http://wordpress.org/plugins/buddypress-upload-avatar-ajax/" target="_blank">Buddypress Upload Avatar Ajax</a> plugin. Although it doesn&#8217;t force the user to upload an avatar, the plugin makes it more convenient for users to personalize their profiles at registration.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Jul 2014 20:54:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WPTavern: Exploring The Idea Of An Internet Archive Specifically For WordPress Content";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26578";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:216:"http://wptavern.com/exploring-the-idea-of-an-internet-archive-specifically-for-wordpress-content?utm_source=rss&utm_medium=rss&utm_campaign=exploring-the-idea-of-an-internet-archive-specifically-for-wordpress-content";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9743:"<p>It seems like each time a WordPress podcast disappears, there is one or more to take its place. A few weeks ago, the <a title="http://wpbacon.com/" href="http://wpbacon.com/">WP Bacon podcast announced</a> the end of their show to concentrate on other projects. However, a recent search in iTunes for WordPress Podcasts show there is almost an endless amount of content to listen to.</p>
<div id="attachment_26577" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/WPWeeklyPodcastLogo.png" rel="prettyphoto[26578]"><img class="size-full wp-image-26577" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/WPWeeklyPodcastLogo.png?resize=1025%2C586" alt="Variety of WordPress Podcasts To Listen To On iTunes" /></a><p class="wp-caption-text">Variety of WordPress Podcasts To Listen To On iTunes</p></div>
<p>Although websites can be archived by the <a title="https://archive.org/index.php" href="https://archive.org/index.php">Internet Archive web crawler</a> to be preserved, podcasts don&#8217;t have that luxury since they are audio files. It&#8217;s disappointing knowing that some WordPress podcasts will be lost to the ether, never to be heard from again. It&#8217;s an even harder pill to swallow if the podcast has 50-100 episodes. It would be great if there was a resource on WordPress.org that acted as a digital archive of WordPress history for text, video, and audio. An enhanced version of the Internet Archive but specifically for WordPress.</p>
<div id="attachment_26580" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/InternetArchiveWordPressDotOrg.png" rel="prettyphoto[26578]"><img class="size-full wp-image-26580" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/InternetArchiveWordPressDotOrg.png?resize=1013%2C801" alt="Results For WordPress.org In The Wayback Machine" /></a><p class="wp-caption-text">Results For WordPress.org In The Wayback Machine</p></div>
<h2>Make Sure Your Site Is Not Blocking The Internet Archive Web Crawler</h2>
<p>The Internet Archive uses web crawlers or spiders to automatically scan and download websites. You can manually trigger the spiders to crawl your site by searching for it using the <a title="https://archive.org/web/" href="https://archive.org/web/">Wayback Machine</a>. If the site is already indexed, you&#8217;ll see a list of results. If not, the Internet Archive will attempt to crawl the site and display the results within six months.</p>
<blockquote><p>It generally takes 6 months or more (up to 24 months) for pages to appear in the Wayback Machine after they are collected, because of delays in transferring material to long-term storage and indexing, or the requirements of our collection partners.</p></blockquote>
<p>A <strong>robots.txt</strong> file at the top-level of a domain is enough to block the Internet Archive from crawling the site, so please don&#8217;t use it. The Archive Team <a title="http://www.archiveteam.org/index.php?title=Robots.txt" href="http://www.archiveteam.org/index.php?title=Robots.txt">explains the history of robots.txt and why it&#8217;s dangerous</a> to preserving the web.</p>
<div id="attachment_26592" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/RobotsTXTImage.png" rel="prettyphoto[26578]"><img class="size-full wp-image-26592" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/RobotsTXTImage.png?resize=638%2C338" alt="Robots" /></a><p class="wp-caption-text">photo credit: <a href="https://www.flickr.com/photos/doctorow/3119144658/">gruntzooki</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a></p></div>
<h2>How To Upload Audio To The Wayback Machine</h2>
<p>In order to upload audio to the Internet Archive, you&#8217;ll need to register for an account to obtain a virtual library card. Once you&#8217;ve registered and activated your account, browser to <a title="https://archive.org/upload/" href="https://archive.org/upload/">https://archive.org/upload/</a>. This is the submission form you&#8217;ll use to upload audio to the Internet Archive. Select the audio file or drag to the screen to begin the process.</p>
<p>With the audio file selected, you&#8217;ll need to fill in additional details such as the description, subject tags, date the work was created, etc. Please be as detailed and descriptive as possible. This is where publishing decent show notes helps as you can just copy and paste the relevant material into the submission form.</p>
<p>One thing you&#8217;ll want to pay particular attention to is the license. If the work is not considered in the public domain, <a title="https://creativecommons.org/choose/zero/" href="https://creativecommons.org/choose/zero/">CC0 is the least restrictive license</a>. While you can choose to be more restrictive, I recommend being the least restrictive license as possible to remove doubt on how the content can be reused. As an example, I uploaded <a title="http://wptavern.com/wpweekly-episode-154-all-about-the-customizer" href="http://wptavern.com/wpweekly-episode-154-all-about-the-customizer">episode 154 of WordPress Weekly</a>.</p>
<div id="attachment_26587" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/UploadingAudioToWaybackMachine.png" rel="prettyphoto[26578]"><img class="size-full wp-image-26587" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/UploadingAudioToWaybackMachine.png?resize=1012%2C681" alt="The Wayback Machine Audio Upload Form" /></a><p class="wp-caption-text">The Internet Archive Audio Upload Form</p></div>
<p>Once the upload process is complete, the Internet Archive <a title="https://archive.org/details/EPISODE154AllAboutTheCustomizer" href="https://archive.org/details/EPISODE154AllAboutTheCustomizer">creates a page</a> dedicated to the piece of audio content. From this page, visitors can read information and listen to the uploaded audio file. I also searched the audio section of the Internet Archive for WordPress Weekly and was able to locate Episode 154 of the show.</p>
<div id="attachment_26590" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/InternetArchiveSearchResults.png" rel="prettyphoto[26578]"><img class="size-full wp-image-26590" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/InternetArchiveSearchResults.png?resize=808%2C404" alt="Internet Archive Search Results For WordPress Weekly Audio" /></a><p class="wp-caption-text">Internet Archive Search Results For WordPress Weekly Audio</p></div>
<p>If you&#8217;ve produced at least 25 or more episodes of a WordPress podcast and have decided to call it quits, could you please consider uploading the shows to the Internet Archive. I realize it&#8217;s manual labor and takes time, but at least your hard work of preparing for each show and the information discussed will not go to waste!</p>
<h2>Uploading Video To The Internet Archive</h2>
<p>Although the Internet Archive has a <a title="https://archive.org/details/movies" href="https://archive.org/details/movies">section devoted to video content</a>, you&#8217;re required to have the source files for upload. These are not only larger, but  require more time and labor to obtain. I doubt <a title="https://www.youtube.com/" href="https://www.youtube.com/">YouTube.com</a> is going anywhere, anytime soon, but if you want your WordPress centric videos to be archived, <a title="https://archive.org/upload/" href="https://archive.org/upload/">this is where you&#8217;d upload them</a>.</p>
<h2>Why Archiving WordPress Information Is Important To Me</h2>
<p>I think of WP Tavern as a site with a continuous mission of documenting what&#8217;s happening within the WordPress ecosystem. Our job is never completed and I value the archived content as if it were gold. When I read posts from the archive, I&#8217;m reminded of how many projects that have come and gone over the past few years. It doesn&#8217;t matter if it&#8217;s text, audio, or video, each piece of content about WordPress whether it&#8217;s published on WP Tavern or not is important, especially when looking at the big picture.</p>
<p>My hope is that websites that write about WordPress on a routine basis do their best to archive content, even if they decide to shut down. For example, if <a title="http://wpcandy.com/" href="http://wpcandy.com/">WPCandy</a> disappears from the web, a large gaping hole of WordPress history will go with it. During the height of WPCandy&#8217;s success, I spent time away from WP Tavern. The Tavern doesn&#8217;t have any relevant content from that time period. When piecing together stories to make sense of decisions and trends, historical content is important. Once those holes are created, it&#8217;s nearly impossible to fill them.</p>
<p>A lot has happened since the birth of WordPress over 10 years ago. Much of WordPress&#8217; earlier history is documented fairly well but the events and milestones between the beginning and the present are spread throughout many sites in text, video, and audio. As someone who writes about WordPress for a living, it&#8217;s important that as much WordPress history as possible is archived. It sucks to view an article about WordPress with a bunch of potentially relevant information to a recent topic of discussion only to discover a 404 error.</p>
<p><strong>How important is it to you that there is a proper archive of historical content related to WordPress and it being available to the public? Is the Internet Archive good enough or would you like to see something catered specifically to WordPress?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Jul 2014 19:36:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WordPress.tv: Sara Cannon: Smart Design – Icon Fonts, SVG, and the Mobile Influence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36422";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:96:"http://wordpress.tv/2014/07/17/sara-cannon-smart-design-icon-fonts-svg-and-the-mobile-influence/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:716:"<div id="v-gjnaujyP-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36422/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36422/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36422&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/17/sara-cannon-smart-design-icon-fonts-svg-and-the-mobile-influence/"><img alt="Sara Cannon: Smart Design &#8211; Icon Fonts, SVG, and the Mobile Influence" src="http://videos.videopress.com/gjnaujyP/video-74a2c378cf_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Jul 2014 15:49:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress.tv: Joakim Hedstrom: Skriv så någon bryr sig";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34910";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.tv/2014/07/17/joakim-hedstrom-skriv-sa-nagon-bryr-sig/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:652:"<div id="v-uwH6AHuH-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34910/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34910/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=34910&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/17/joakim-hedstrom-skriv-sa-nagon-bryr-sig/"><img alt="Joakim Hedstrom: Skriv så någon bryr sig" src="http://videos.videopress.com/uwH6AHuH/video-a72d3c5725_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Jul 2014 15:44:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: WPcast.fm Billed As The Professional WordPress Podcast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26494";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:172:"http://wptavern.com/wpcast-fm-billed-as-the-professional-wordpress-podcast?utm_source=rss&utm_medium=rss&utm_campaign=wpcast-fm-billed-as-the-professional-wordpress-podcast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3997:"<div id="attachment_26573" class="wp-caption alignright"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/WPCastLogo.png" rel="prettyphoto[26494]"><img class="wp-image-26573 size-medium" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/WPCastLogo.png?resize=300%2C300" alt="The Logo For WPcast.fm" /></a><p class="wp-caption-text">The Logo For WPcast.fm</p></div>
<p>Billed as <em>The Professional WordPress Podcast</em>, <a title="http://wpcast.fm/" href="http://wpcast.fm/">WPcast.fm</a> is the latest entrant into the WordPress podcasting scene. Produced by <a title="http://efficientwp.com/" href="http://efficientwp.com/">Doug Yuen</a> and <a title="http://fatcatapps.com/" href="http://fatcatapps.com/">David Hehenberger,</a> the show focuses on the professional aspects of WordPress such as <a title="http://wpcast.fm/consulting" href="http://wpcast.fm/consulting">how to be a better business consultant</a>, <a title="http://wpcast.fm/hiring" href="http://wpcast.fm/hiring">how to hire great software developers</a>, and <a title="http://wpcast.fm/payments" href="http://wpcast.fm/payments">the best ways to take payments with WordPress</a>. The duo releases a new episode every Wednesday morning at 8AM Eastern.</p>
<h2>The Origins Of WPcast.fm</h2>
<p>Yuen and Hehenberger met in Bali a few years ago along with a few other independent entrepreneurs. Since then, the pair have kept in touch while at times, their travel paths have crossed. Earlier this year, Hehenberger approached Yuen with the idea of starting the podcast. &#8220;We were already talking plenty of WordPress business with each other, and we&#8217;ve seen the benefits of podcasting, so we figured it would be a great way for us to share our knowledge and engage with the WordPress community,&#8221; Yuen said.</p>
<div id="attachment_26572" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/StartupsForTheRestOfUsLogo.png" rel="prettyphoto[26494]"><img class="size-full wp-image-26572" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/StartupsForTheRestOfUsLogo.png?resize=343%2C162" alt="The Logo For The Startups For The Rest Of Us Podcast" /></a><p class="wp-caption-text">The Logo For The Startups For The Rest Of Us Podcast</p></div>
<p>The format of the show is based on the podcast <a title="http://www.startupsfortherestofus.com/" href="http://www.startupsfortherestofus.com/">Startups For The Rest Of Us</a>, which focuses on specific actionable information instead of interviews or broad business strategy. Each episode is between 20-30 minutes long. Despite Hehenberger&#8217;s strong accent, he&#8217;s easy to understand. Those who value their time will appreciate that the show is to the point and doesn&#8217;t contain filler material.</p>
<h2>Putting Listeners First</h2>
<p>Yuen told me they have a bunch of ideas for upcoming shows but ultimately, they want to know what their listeners want to hear. Yuen said, &#8220;We&#8217;ll try to put listener suggestions at the top of the queue. If you have any suggestions, <a title="http://wpcast.fm/contact" href="http://wpcast.fm/contact">we&#8217;re all ears</a>.&#8221; While some topics cover a broad audience like backups, they also go into technical detail with plugins and themes. In future episodes, Yuen and Hehenberger will go into detail about their own products, services, and experiences with running a business.</p>
<p>The following is episode six of WPcast. If you like what you hear, consider <a title="https://itunes.apple.com/us/podcast/professional-wordpress-podcast/id885696994" href="https://itunes.apple.com/us/podcast/professional-wordpress-podcast/id885696994">subscribing to the show on iTunes</a>.</p>
<!--[if lt IE 9]><script>document.createElement(\'audio\');</script><![endif]-->
<a href="http://media.blubrry.com/wpcast/p/s3.amazonaws.com/wpcast/WPCAST006.mp3">http://media.blubrry.com/wpcast/p/s3.amazonaws.com/wpcast/WPCAST006.mp3</a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Jul 2014 05:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: WordPress Tip: New Plugin Automatically Gets Featured Images from Videos";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26552";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:206:"http://wptavern.com/wordpress-tip-new-plugin-automatically-gets-featured-images-from-videos?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-tip-new-plugin-automatically-gets-featured-images-from-videos";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2239:"<p>When you post a video or include it in your content, chances are that you don&#8217;t want to have to hunt around for a featured image to accompany it. However, many WordPress themes look their best with featured images in the homepage, category, and archive templates. Without featured images, many image-dependent designs can break or look inconsistent.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/video-featured-images.jpg" rel="prettyphoto[26552]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/video-featured-images.jpg?resize=295%2C500" alt="video-featured-images" class="alignright size-large wp-image-26561" /></a><a href="http://wordpress.org/plugins/automatic-featured-images-from-videos/" target="_blank">Automatic Featured Images from Videos</a> is a new free plugin from the folks at <a href="http://webdevstudios.com/" target="_blank">WebDevStudios</a>. Created for sites that are heavy on video content, the plugin will automatically grab the thumbnail of a YouTube or Vimeo video that occurs within the first 1000 characters of a post.</p>
<p>I tested the plugin and found that it works unobtrusively in the background. It doesn&#8217;t require anything extra when adding a video in a post. As soon as the draft finishes saving, you&#8217;ll see the new featured image assigned. The screenshot included here shows videos from both Youtube and Vimeo with thumbnails automatically added by the plugin.</p>
<p>Automatic Featured Images from Videos currently only works with a full URL, i.e. http://www.youtube.com/watch?v=ScMzIvxBSi4 and does not work with a shortened URL like http://youtu.be/ScMzIvxBSi4. It also works when using the full embed code. I spoke with Brad Parbs who said that the team is currently working on a patch to ensure that the shortened URLs work, too. They also plan to add a few more popular video services in a future release.</p>
<p>If you post a lot of video content, then the <a href="http://wordpress.org/plugins/automatic-featured-images-from-videos/" target="_blank">Automatic Featured Images</a> plugin will be a real time saver for you and will keep your homepage and archives looking colorful. Download it for free from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Jul 2014 00:30:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: Translate WordPress Plugins and Themes Directly in Your Browser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26106";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:190:"http://wptavern.com/translate-wordpress-plugins-and-themes-directly-in-your-browser?utm_source=rss&utm_medium=rss&utm_campaign=translate-wordpress-plugins-and-themes-directly-in-your-browser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4928:"<p><a href="https://localise.biz/" target="_blank">Loco</a> is a free service for managing and editing software translations. Many WordPress plugins and themes include language files that make it possible for users to translate the text strings. Loco offers a place to manage assets associated with translations and easily collaborate with translators:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/manage-translations.png" rel="prettyphoto[26106]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/manage-translations.png?resize=800%2C600" alt="manage-translations" class="aligncenter size-full wp-image-26505" /></a></p>
<p>The service also offers a <a href="https://localise.biz/free/poedit" target="_blank">PO file editor</a> that works just like <a href="http://poedit.net/" target="_blank">Poedit</a>, except directly within your browser. You simply drop in a PO file to edit &#8211; no account required.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/loco.jpg" rel="prettyphoto[26106]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/loco.jpg?resize=984%2C566" alt="loco" class="aligncenter size-full wp-image-26499" /></a></p>
<p>The service analyzes the file and prepares it for translation in the browser. Once you&#8217;re finished editing, you can download the updated .po and/or .mo files, or create an account (optional) and store the files with the Loco service.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-po.jpg" rel="prettyphoto[26106]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-po.jpg?resize=977%2C675" alt="edit-po" class="aligncenter size-full wp-image-26511" /></a></p>
<h3>Loco Translate Lets You Translate Plugins and Themes in the WordPress Admin</h3>
<p><a href="http://timwhitlock.info/" target="_blank">Tim Whitlock</a>, founder of the Loco translation management system, created a WordPress plugin that allows users to translate plugins and themes directly within the WordPress admin. <a href="http://wordpress.org/plugins/loco-translate/" target="_blank">Loco Translate</a> brings the PO editor into the admin under the Tools menu where you view and manage all available translations for your plugins and themes:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/available-translations-themes.jpg" rel="prettyphoto[26106]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/available-translations-themes.jpg?resize=776%2C383" alt="available-translations-themes" class="aligncenter size-full wp-image-26549" /></a></p>
<p>Select from any of the available packages to start translating strings in the admin with the Loco PO Editor:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-translation.jpg" rel="prettyphoto[26106]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-translation.jpg?resize=815%2C521" alt="edit-translation" class="aligncenter size-full wp-image-26550" /></a></p>
<p>When you save a new PO file, Loco will try to compile an MO file in the same location. It was designed to work purely with PO files and allows you to keep them up to date with the source code without the interim step of maintaining a POT file. The plugin includes the following features:</p>
<ul>
<li>POEdit style translations editor within WordPress admin</li>
<li>Create and update language files directly in your theme or plugin</li>
<li>Extraction of translatable strings from your source code</li>
<li>Native MO file compilation without the need for Gettext on your system</li>
<li>Support for PO features including comments, references and plural forms</li>
<li>Configurable PO file backups</li>
</ul>
<p>Loco Translate does not currently have the ability to automatically translate your project; it is only capable of handling the manual entry of translations. However, Whitlock is working on integrating some automatic translation services into the plugin in a future release.</p>
<p>The Loco service and Loco Translate plugin make translating WordPress themes and plugins much more convenient. It eliminates the requirement of adding an additional translation program to your machine and the task of moving files back and forth. Hosting your files on the free Loco service is entirely optional, but it has the added benefit of providing a centralized place for translators to collaborate on your project.</p>
<p>You don&#8217;t have to be a developer to use Loco&#8217;s browser translation tools. Having those tools at your fingertips in the admin might make it easier for your average WordPress user to create their own custom language files. Check out <a href="http://wordpress.org/plugins/loco-translate/" target="_blank">Loco Translate</a> on WordPress.org. Do you think if it offers a more convenient solution than what you&#8217;re currently using?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Jul 2014 20:03:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WPTavern: Keep Track Of Changes To Your WordPress Site With The WP SMS Notifications Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:226:"http://wptavern.com/keep-track-of-changes-to-your-wordpress-site-with-the-wp-sms-notifications-plugin?utm_source=rss&utm_medium=rss&utm_campaign=keep-track-of-changes-to-your-wordpress-site-with-the-wp-sms-notifications-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3558:"<p>While there are plenty of plugins that help monitor changes to a site such as <a title="http://wordpress.org/plugins/stream/" href="http://wordpress.org/plugins/stream/">Stream</a>, maybe you want a text message when specific events happen within WordPress. A brand new plugin called <a title="http://wordpress.org/plugins/wp-sms-notifications/" href="http://wordpress.org/plugins/wp-sms-notifications/">WP SMS Notifications,</a> developed by Jeff Matson, fulfills this role. The plugin supports both International and US carriers without the need to use an external API. After activation, you&#8217;ll find the settings in a top-level menu item titled WP SMS Notifications. You can configure notifications for the following events:</p>
<div id="attachment_26517" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/WPSMSNotificationsSettingsScreen2.png" rel="prettyphoto[26500]"><img class="size-full wp-image-26517" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/WPSMSNotificationsSettingsScreen2.png?resize=674%2C762" alt="Configuration Screen For WP SMS Notifications" /></a><p class="wp-caption-text">Configuration Screen For WP SMS Notifications</p></div>
<p>Text messages are sent immediately after being triggered. If you have a limited amount of text messages as part of your mobile plan, be careful with enabling notifications for when a post is updated. Each time a draft post is saved, published, or a published post is updated, a notification is generated. This could quickly use up your available text messages, especially if you&#8217;re using it on a multi-author site.</p>
<p>Here&#8217;s the text message I received after updating a plugin. As you can see, there is just enough information to tell you what happened.</p>
<div id="attachment_26538" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/PluginUpdateNotificationTextMessage2.png" rel="prettyphoto[26500]"><img class="size-full wp-image-26538" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/PluginUpdateNotificationTextMessage2.png?resize=626%2C461" alt="Text Message Notifying Me A Plugin Has Been Updated" /></a><p class="wp-caption-text">Text Message Notifying Me A Plugin Has Been Updated</p></div>
<p>One thing I&#8217;d like in a future version is a cleaner FRM message. Instead of detailed information of the mail server, I&#8217;d rather see which domain generated the message. This would be especially helpful if the plugin is used on multiple domains.</p>
<p>I asked Matson what motivated him to create his first WordPress plugin. He said, &#8220;It&#8217;s been a long time since I&#8217;ve done any real development work so when I entered the office on a Friday morning, I decided I would use that desire to make something useful for the community.&#8221;</p>
<p>Matson recommends that you don&#8217;t use this plugin in a production environment just yet. He needs a group of beta testers to discover bugs and is accepting feature requests to help him plan his roadmap. You can find the <a title="https://github.com/JeffMatson/WP-SMS-Notifications" href="https://github.com/JeffMatson/WP-SMS-Notifications">plugin on Github</a> where pull requests are welcome. Support is being handled through the <a title="http://wordpress.org/support/plugin/wp-sms-notifications" href="http://wordpress.org/support/plugin/wp-sms-notifications">WordPress.org support forum.</a></p>
<p>If you have feature requests or feedback, let us know in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Jul 2014 19:42:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WordPress.tv: Andreas Ek: Web Production Automation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34893";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wordpress.tv/2014/07/16/andreas-ek-andreas-ek-web-production-automation/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:661:"<div id="v-6Zu9uyPr-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34893/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34893/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=34893&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/16/andreas-ek-andreas-ek-web-production-automation/"><img alt="Andreas Ek: Web Production Automation" src="http://videos.videopress.com/6Zu9uyPr/video-9ddb4ba7ae_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Jul 2014 15:35:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WordPress.tv: Brennen Byrne: Passwords – The Weakest Link in WordPress Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36569";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:96:"http://wordpress.tv/2014/07/16/brennen-byrne-passwords-the-weakest-link-in-wordpress-security-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:712:"<div id="v-hVfmDSkB-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36569/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36569/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36569&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/16/brennen-byrne-passwords-the-weakest-link-in-wordpress-security-2/"><img alt="Brennen Byrne: Passwords &#8211; The Weakest Link in WordPress Security" src="http://videos.videopress.com/hVfmDSkB/video-c2c8d8b875_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Jul 2014 15:17:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WordPress.tv: Ross Johnson: Designing for the First Five Seconds";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36515";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://wordpress.tv/2014/07/16/ross-johnson-designing-for-the-first-five-seconds/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:676:"<div id="v-ycTRqlmR-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36515/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36515/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36515&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/16/ross-johnson-designing-for-the-first-five-seconds/"><img alt="Ross Johnson: Designing for the First Five Seconds" src="http://videos.videopress.com/ycTRqlmR/video-ee04b92a39_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Jul 2014 15:11:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"Post Status: How much should a custom WordPress website cost?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=6897";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:112:"http://www.poststat.us/wordpress-website-cost/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-website-cost";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:23664:"<p><img class="aligncenter size-large wp-image-6900" src="http://www.poststat.us/wp-content/uploads/2014/07/custom-wordpress-website-cost-752x300.jpg" alt="The cost of a custom WordPress website" width="752" height="300" />Eventually, you have to talk about cost.</p>
<p>If you&#8217;re a consultant, as I am, you&#8217;ve been asked how much your services cost. And you have to make some decisions:</p>
<ul>
<li>What services am I providing?</li>
<li>How many hours do I think this will take me?</li>
<li>How much is this worth to the client, from a business perspective?</li>
<li>Does the client have money? How about a business plan?</li>
<li>Should I charge hourly or by project?</li>
<li>Is this a one off thing or is there potential for a long term relationship?</li>
<li>How busy am I? Do I need this job? Do I want it?</li>
</ul>
<p>These questions are important. The answers are important. Gauging the client is important. Every interaction I have with the client helps me learn more about them and the project at hand, and affects what the cost will be.</p>
<p>Cost often also depends on market and location. I&#8217;m assuming I&#8217;m talking to an American audience in US dollars. What follows may translate well or poorly depending on your location and culture.</p>
<h3>How much should a custom WordPress website cost?</h3>
<p>I&#8217;ve built websites or been a part of website projects &#8212; all on WordPress &#8212; that have ranged in cost from under $1,000 to over $100,000, for complete websites.</p>
<p>So in short: <strong>it always depends</strong>.</p>
<p>This is why we <a href="http://chrislema.com/the-art-of-giving-an-estimate/">can&#8217;t ballpark it for you</a>.</p>
<p>And as Chris notes in that link, &#8220;Most people’s budget is 2-3 times smaller than their desires or expectations.&#8221; And if I ballpark anything specific it&#8217;s highly unlikely both of us will be happy once it&#8217;s all said and done.</p>
<h4>A proper estimate costs money</h4>
<p>An estimate takes time. Whether that time is in a paid discovery or a sunk cost I (the consultant) bring on myself is a different matter. Either way, estimates are expensive because they are time consuming. And I promise you if I spend a week on an estimate or proposal I&#8217;m putting that cost into the proposal, somewhere.</p>
<h3>Who is the consultant?</h3>
<p>There are some broad brush common price ranges I can establish for you. I&#8217;m trying my best to be specific with this post, though that&#8217;s really, really hard.</p>
<p>Let&#8217;s start by segmenting based on who you are working with. Basically, working with a freelancer will normally be cheaper than working with an agency.</p>
<p>Agencies have more overhead, more padding built in, are more worried about cash flow, and generally just tend to be a bit more expensive.</p>
<p>If you work with an agency, the risk of them falling off the map is generally a little lower, but they probably move a little slower too. And you&#8217;ll often have to deal with changing contacts as the project progresses (from sales to design to development to maintenance).</p>
<p>If you work with a freelancer, your risks are a bit higher they&#8217;ll disappear someday. It means vetting them is even more important than with an agency. But they also tend to move quickly and don&#8217;t juggle as many projects at once. You also have the benefit of working with (typically) one person that knows everything about your project, and you don&#8217;t feel like you&#8217;re constantly getting bounced around contacts like can happen in some agencies.</p>
<p>It&#8217;s possible to have a great relationship with a freelancer or with an agency. I think it typically depends on the client&#8217;s mentality and requirements as to determining which route is better.</p>
<p>In general, freelancers are great for jobs that fit the following criteria:</p>
<ul>
<li>The job is small enough for one person to handle the entire thing (note, most projects fit this category)</li>
<li>The timeline is tight, and you want them to start quickly</li>
<li>Communication channels don&#8217;t have to be too formal</li>
<li>Big contractor agreements don&#8217;t have to be signed and the contractor doesn&#8217;t need insurance or other common big-business requirements</li>
</ul>
<p>In general, agencies are better for the following criteria:</p>
<ul>
<li>You don&#8217;t want to risk your consultant disappearing</li>
<li>You&#8217;re okay with a project structure you don&#8217;t define (most agencies have established processes)</li>
<li>You&#8217;re okay with a multi-month project (I&#8217;d say most agency projects last between 2-6 months)</li>
<li>You don&#8217;t mind waiting until you can be fit into their schedule to start (often 30-90 days&#8230; but great freelancers often have significant backlogs too)</li>
<li>You want a dedicated project manager (some freelancers are phone-call averse)</li>
<li>Your project will require multiple full-time folks working simultaneously, either due to deadlines or huge project scope</li>
</ul>
<h4>Freelancer rates vs Agency rates</h4>
<p>I don&#8217;t want to get into hourly versus project billing. But either way, for most projects the consultant has to estimate the time it&#8217;s going to take them to build, and charge <em>at least</em> that. So I&#8217;m going to assume the consultant is not charging an amount enormously higher than their cost just because it&#8217;s worth it to the client.</p>
<p>Whether the consultant is an agency or a freelancer, I&#8217;m going to assume 50% &#8220;billable&#8221; or productive time. In other words, I&#8217;m only figuring that half of anyone&#8217;s day is spent actually building what&#8217;s being paid for. I think this is a good goal for most and also quite achievable with discipline. Also, I think that number is probably higher for your average web-worker in an agency, but still works as an average because managers and PMs typically won&#8217;t hit 50%, if their time is counted into direct costs at all.</p>
<p>I&#8217;m also going to assume the freelancer is billing an end client, not subcontracting to an agency where their costs go considerably down due to less PM and consistent work.</p>
<p>Finally, I&#8217;m utilizing these hourly rates as if it&#8217;s for billable work and known costs. So, if the rate is $100 per hour and the design will take 50 hours and the development will take 50 hours and you build in 25 hours for project management, it would be 125 hours and the project would cost $12,500. Profits, overhead, and everything else are &#8220;built in&#8221; to the internal hourly rate &#8212; just like if someone were billing the client hourly for the work.</p>
<p><strong>Freelancer rates</strong></p>
<ul>
<li>Beginner freelancer: $25-$40 per hour</li>
<li>Intermediate freelancer: $40-75 per hour</li>
<li>Good, experienced freelancer: $75 &#8211; $125 per hour</li>
<li>Excellent, in demand freelancer: $125 &#8211; $175 per hour</li>
<li>Specialist, best in industry: $175 &#8211; $400 per hour</li>
</ul>
<p><strong>Agency rates</strong><span id="more-6897"></span></p>
<ul>
<li>Small market general agency: $50 &#8211; $75 per hour</li>
<li>Medium market general agency: $75 &#8211; $115 per hour</li>
<li>Medium market reputable agency: $115 &#8211; $150 per hour</li>
<li>Medium market high end agency: $150 &#8211; $175 per hour</li>
<li>Medium market best in industry agency: $175 &#8211; $225 per hour</li>
<li>Large market reputable agency: $150 &#8211; $175 per hour</li>
<li>Large market high end agency: $175 &#8211; $250 per hour</li>
<li>Large market best in industry agency: $200 &#8211; $275 per hour</li>
</ul>
<p>When I say &#8220;best in industry&#8221;, I&#8217;m referring to an agency that&#8217;s made a name for itself in regard to something specific &#8211; maybe high-end WordPress websites, or Ruby on Rails, or websites for newspapers, or eCommerce. It depends.</p>
<p>When I talk market size, I mean the difference between working in big towns or small cities (small market), cities that are thriving but not huge like my own Birmingham, AL (medium market), or the type of city that&#8217;s got pro sports teams and 1 million+ people (large market). Not listed, but notable, are the mega-markets like New York and San Francisco types. I&#8217;m sure you can pay as much as you desire for services in such places.</p>
<p><strong>Also, these are all guesses.</strong></p>
<p>Please, please, please don&#8217;t take these guesses as offense. I&#8217;m purely trying to show you a picture of the landscape, as best as I see it.</p>
<p>I talk to a lot of people. I read a ton. I listen to a ton of podcasts. I go to conferences. But I&#8217;ve only worked at two agencies and freelanced on the side. But I think I have a decent take on the market, and I think this is a practical range to work with.</p>
<h4>Consultants break their own rules all the time</h4>
<p>Freelancers and agencies also break their own rules all the time. A great example of this is when you get an inquiry from a big brand.</p>
<p>If it&#8217;s a competitive bid, and a consultant wants that brand as a featured client, they could easily drop their rates by a third or more to get it &#8212; with the hope that that brand will make other folks want to work with them down the road. Sometimes this is effective, sometimes it&#8217;s a terrible idea. My guess is that referrals can come from anywhere, and generally bending your rates for a brand name is a bad idea; I also want to do it in the heat of the moment all the time.</p>
<p>There are other times consultants break their own rules or don&#8217;t follow their internal rates. Consultants may charge less if it&#8217;s a client they work with over and over and know the true costs better. Consultants may charge less for non-profit organizations, or may charge less if a retainer is promised, or may charge less if work is slow, or may charge less if they get emotionally invested in the bid. The list of ways to break the guidelines goes on and on.</p>
<h3>Who is the client?</h3>
<p>The client is a huge factor in price. In short, if I gauge that a client is going to be difficult, it affects the client multiplier I put on the overall project cost.</p>
<h4>What is a client multiplier?</h4>
<p>Well, I&#8217;m glad you asked! Over a number of years, I&#8217;ve started to pick up on client qualities that end up costing money. Here are some things that can get expensive:</p>
<ul>
<li>The client doesn&#8217;t have a single point of contact (multiple people always have to be looped into communication)</li>
<li>The client contact has to get some form of committee approval</li>
<li>The client contact isn&#8217;t decisive, or doesn&#8217;t seem capable to play the &#8220;consultant advocate&#8221; role well internally</li>
<li>The client has a lot of red tape for decision making</li>
<li>The client&#8217;s payment schedules are really bad (as in, I might not get paid for work I&#8217;ve done for months)</li>
<li>The client contact is prone to huge email threads over small issues</li>
<li>The client contact wants daily/frequent phone calls or meetings</li>
<li>The client doesn&#8217;t have a clear business plan, and will require a lot of advising</li>
</ul>
<p>These are mostly people and organizational things. They have little to do with the actual project.</p>
<p>Let&#8217;s say the work for a project will be around $20,000. I usually add up these client qualities that could get costly from a project management perspective and apply them to the overall cost.</p>
<p>In a $20,000 project, it&#8217;s not uncommon for $5,000 of that to be project management costs. If I decide there are enough concerns to warrant 50% higher PM costs, the project gets a $2,500, or 12.5%, increase in overall project cost.</p>
<p>Looking for client qualities that trigger higher costs is important as a consultant. And for potential clients out there: keep in mind that your qualities (organizational and behavioral) affect your consultant&#8217;s price.</p>
<h3>Costs ranges for different types of websites</h3>
<p>There are many types of websites, and each has their own potential costs associated.</p>
<h4>The many different types of websites</h4>
<p>I tend to rank sites in complexity like this:</p>
<ul>
<li>Simple blog (2-3 views): Archives and single post views only, and a pretty typical layout.</li>
<li>Simple brochure site (2-4 views): Fairly standard but custom home page design, page layout. Stock archive / blog setup with little to no customizations.</li>
<li>Complicated blog (4-6 views): A bunch of &#8220;out of the box&#8221; styles for various templates, requires attention to detail on archives, single posts, and other stuff like post formats.</li>
<li>Marketing site (3-7 views): Basically a mashup between the simple brochure and complicated blog. Requires more designs to be made and the home page might be a little more advanced than the simple brochure.</li>
<li>Business website (5-12 views): Similar to a marketing site, but often includes a couple of custom content types that require design and code, like events, testimonials, services, etc.</li>
<li>eCommerce website (10-25 views): Could be a mix of any of the websites above, plus all the needs in eCommerce (like cart/account/checkout views, and tons of configuration considerations). This is often a huge PM bump as well.</li>
<li>Big non-profits or advocacy sites (10-30 views): I&#8217;ve found that non-profits and advocacy sites are pretty much the holy grail of wanting everything on a budget. These are really hard to keep in scope because they often have the same needs of big businesses, without the budgets.</li>
<li>Big business website (12-30+ views): Big business websites are like regular business websites, but more of it. They often have lots of custom content types, advanced searching needs, tons of content, and perhaps some fancy user permissions needs. And of course potentially much, much, more.</li>
<li>Big scale: You can take pretty much any of these types of websites and then say you need it to handle millions of pageviews per month without breaking a sweat, and a whole new layer of complexity comes into play.</li>
</ul>
<p>The hours it takes to build these different types of websites vary can vary tremendously; it depends on the consultant&#8217;s experience, whether they&#8217;ve done similar work before, how many &#8220;gotchas&#8221; appear in the project, how particular the client is about any given feature, and more.</p>
<p>However, I tend to believe in a few key concepts about pricing.</p>
<h4>Pricing views</h4>
<p>Generally, I try to estimate how many unique views a website has in order to wrap my head around how much it&#8217;s going to cost.</p>
<p><strong>What&#8217;s a unique view?</strong></p>
<ul>
<li>The home page is a unique view.</li>
<li>The archive page is a unique view. Though archive pages could be category, search, and more all combined in one unique view.</li>
<li>The blog &#8220;post&#8221; page is a unique view.</li>
<li>The generic &#8220;page&#8221; template is a unique view, though can sometimes be mashed with the post view.</li>
<li>Custom page templates &#8212; like fancy about us pages, or a key landing page &#8212; are unique views.</li>
<li>Custom post types are often unique views &#8212; sometimes in the traditional archive/singular sense and other times the way it sits within another view: like how an FAQ content type may fit into a regular page.</li>
<li>Variable sidebars within sections of the website can be unique views</li>
</ul>
<p>Unique views aren&#8217;t always obvious. I usually figure out more necessary unique views depending on how my discovery conversations go with the client.</p>
<p>What&#8217;s important about unique views is that they are excellent for estimating design time, and they at least can help guide estimating development time.</p>
<p>If a unique view requires a comp (design preview for the client), then that&#8217;s a relatively set number of hours for design that are required. If it doesn&#8217;t require a comp, I usually still build in some time for the designer to quality check after it&#8217;s been developed, so they can make sure it looks good.</p>
<p>Designing a unique view, from the ground up, could take a designer between 4 and 10 hours depending on the complexity; and for certain complex or innovative views that number could hit upwards of 20 hours. Just for design.</p>
<p>Also, design requires a base set of hours to establish the overall tone of the website and to design things that are rarely considered with unique views, like the header, footer, and overall style guide. The base elements and style guide for the website could easily range between 10 and 100 hours. Yes, I know that&#8217;s a ridiculous range. You should be accustomed to this by now.</p>
<p>So, we&#8217;ve sort of established a framework for pricing the design of unique views. Developing them is a different story.</p>
<p>Development must be carefully considered. Generally, my rule of thumb is that every design hour should get a development hour to go with it. But development hours can easily break that rule, especially when you are developing something complex. I use that rule for when the thing being developed is a known entity &#8212; like if you&#8217;re building a custom post type for a team page or something.</p>
<p>Development hours can be <em>literally anything</em> for wholly custom functionality, and that is completely outside the scope of this post. Development can cost millions of dollars.</p>
<h4>Pricing Content</h4>
<p>With WordPress, you can add as many posts and pages as you want. This is true. I&#8217;ve also found that the more posts or pages the client&#8217;s existing website has (and expects to transfer to the new site), the more complex the new project will be.</p>
<p>I don&#8217;t have a perfect factor for increasing the price of a proposal because there is a lot of content, but I have some levels that I consider worth noting.</p>
<ul>
<li>If there are less than ten pages, no big deal.</li>
<li>If there are more than 30 pages, you better start thinking about structure.</li>
<li>If pages are hierarchical (lots of parent &gt; child page relationships) it&#8217;s going to cost strategic thinking time.</li>
<li>If there are hundreds of pages, there&#8217;s either a problem or a lot of strategy and design consideration to be made.</li>
<li>If there are thousands of blog posts, taxonomies (category / tag handling) and search are going to be important to consider, and will probably require more cost.</li>
<li>If there is a lot of content (of any sort), navigation needs to be uniquely priced for internal quoting purposes.</li>
<li>If it&#8217;s a multi-author blog (likely with big blogs), it&#8217;s going to need special consideration.</li>
<li>If pages or posts need editorial workflow (section management, change or publishing approval, etc), it&#8217;s going to need special consideration.</li>
<li>If the current CMS isn&#8217;t WordPress, the migration is a huge deal and you need some great language and details about how that&#8217;s going to happen.</li>
<li>If the current CMS is WordPress, you need to know what plugins or custom code is potentially creating shortcodes or other weird content handling (maybe with custom fields), or what other bad practices may have taken place and need to be accounted for.</li>
</ul>
<p>These are just some quick thoughts on content. There are more, but this is a great starting point.</p>
<h4>Custom design vs a pre-built theme</h4>
<p>You may have noticed I have not once brought up the question of whether the website is built using custom design or with a pre-built distributed WordPress theme.</p>
<p>Websites cost money for many reasons beyond the base styles.</p>
<p>Yes, custom design costs more than pre-built themes &#8212; until you try to add functionality to or modify the way something works in a template. Then you want to cry and run into a hole and pity yourself for having charged less money for using a pre-built theme.</p>
<p>For small sites, the question of custom vs pre-built themes is a big one. As the site gets bigger and more complex, the savings for using a pre-built theme are far less and can easily invert.</p>
<p>In short: clients shouldn&#8217;t get too excited about the potential cost savings of pre-built themes and consultants should be careful about charging less for them.</p>
<h3>Pricing is hard</h3>
<p>Are you confused? Good.</p>
<p><strong>Pricing is hard. Really. Hard.</strong></p>
<p>People write books on this subject. I&#8217;ve written over 3,000 words and I&#8217;m not sure I&#8217;ve done it any justice at all.</p>
<h4>Custom website prices</h4>
<p>Okay, so after all of this, how much is it, you ask again? Hopefully now you realize it could be anything. People are not kidding when they say $1,000 or $1,000,000 (or more!).</p>
<p>However, in the interest of being helpful, I think here are some &#8220;ballparks&#8221; to consider:</p>
<p>Can you get a custom website for under $3,000? Yes, but be very careful, and know your risk of getting something imperfect is high.</p>
<p>If you work with a good freelancer, I think ~70% of custom websites for average folks and average businesses will cost between $3,000 and $15,000.</p>
<p>If you work with a good agency in a medium market, I think ~70% of custom websites for average folks and average businesses will cost between $8,000 and $40,000.</p>
<p>This difference from freelancers is because larger sites will naturally gear toward agencies, and agencies will be less likely to take on smaller projects if they can take bigger ones instead. That said, some agencies love the small jobs, because they get really good over time at doing quality work in less time than the competition.</p>
<p>If you work with a best in business freelancer to build something special (whether a simple blog or complex website), you&#8217;ll probably spend between $10,000 and $50,000+. The freelancer you work with will probably utilize a team of other subcontractors in this scenario, because it&#8217;s rare for someone to truly deliver all the things you need running solo.</p>
<p>If you work with a best in business agency to build something special (whether a simple blog or complex website), you&#8217;ll probably spend between $15,000 and $100,000+. Most agencies will self-perform the work, and often times you can expect them to be available for retainer contracts, hosting / maintenance agreements, and other long-term relationship style services.</p>
<p>It&#8217;s also worth noting that in large projects, it&#8217;s very common to break them into multiple projects and phase them. This is very typical with six-figure clients, and in these scenarios it&#8217;s not uncommon for some agencies to have million dollar per year clients, whether billed hourly, by project, or a combination of both.</p>
<hr />
<p>I write this post for three audiences:</p>
<ol>
<li>Clients looking to hire a consultant, and not knowing what to consider when comparing costs</li>
<li>Consultants trying to wrap their head around pricing</li>
<li>Me, because I&#8217;ve been building websites for years and pricing them for a couple of those years, and I&#8217;m not even close to having it down</li>
</ol>
<p>I hope this has helped you, and I apologize if it offended you.</p>
<p>If you have more to add, please let me know in the comments. I know many of my readers have much greater wisdom on this subject than I do.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Jul 2014 08:24:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: Responsible Plugin Adds a Responsive Testing Kit to the WordPress Admin Bar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26433";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:214:"http://wptavern.com/responsible-plugin-adds-a-responsive-testing-kit-to-the-wordpress-admin-bar?utm_source=rss&utm_medium=rss&utm_campaign=responsible-plugin-adds-a-responsive-testing-kit-to-the-wordpress-admin-bar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2962:"<p>January 2014 marked the first month that <a href="http://money.cnn.com/2014/02/28/technology/mobile/mobile-apps-internet/">mobile traffic has overtaken PC traffic</a> on the internet in the US, accounting for 55% of Internet usage. As mobile traffic is on the rise, <a href="http://hanno.co/logbook/why-designing-in-the-browser-is-the-way-forward" target="_blank">designing in the browser</a> has become more popular, as it offers better tools for testing sites against various devices.</p>
<p><a href="http://wordpress.org/plugins/responsible/" target="_blank">Responsible</a> is a plugin that adds viewport resizing to the WordPress admin bar with support for six different device sizes. If you&#8217;ve ever used a browser bookmarklet in the past to test how a site appears in different devices, the Responsible plugin essentially replicates that same experience within the WordPress admin. It adds a little viewer icon to the admin bar, which refreshes the page with the viewport resizing panel.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/responsible.png" rel="prettyphoto[26433]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/responsible.png?resize=900%2C340" alt="responsible" class="aligncenter size-full wp-image-26434" /></a></p>
<p>Clicking on the device icons will automatically resize the site, whether in the admin or on the frontend. Below is an example of viewing a website at iPhone dimensions:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/responsible-test.png" rel="prettyphoto[26433]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/responsible-test.png?resize=845%2C388" alt="responsible-test" class="aligncenter size-full wp-image-26473" /></a></p>
<p>Responsible includes the following common viewport sizes for testing, in addition to custom sizes:</p>
<ul>
<li>Mobile: 320&#215;480 (Portrait), Ratio: 2:3</li>
<li>Apple iPhone 5: 320&#215;568 (Portrait), Ratio: 40:71</li>
<li>Small Tablet: 600&#215;800 (Portrait), Ratio: 3:4</li>
<li>Tablet (e.g. Apple iPad 2-3rd, mini): 768&#215;1024 (Portrait), Ratio: 3:4</li>
<li>Widescreen: 1280&#215;800 (Landscape), Ratio: 8:5</li>
<li>HDTV 1080p: 1920&#215;1080 (Landscape), Ratio: 16:9</li>
</ul>
<p>If you prefer using the the tool as a bookmarklet, the plugin comes with a <a href="http://wordpress.org/plugins/responsible/faq/" target="_blank">filter</a> that allows you register a custom bookmarklet. You can then generate your own bookmarklet using the <a href="http://lab.maltewassermann.com/viewport-resizer/" target="_blank">Viewport Resizer</a> tool.</p>
<p>Responsible is perfect for designing in the browser with WordPress or for some quick responsive testing when you don&#8217;t have access to all the different devices. <a href="http://wordpress.org/plugins/responsible/" target="_blank">Download</a> it from WordPress.org or add it to your site via the admin plugins screen.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Jul 2014 23:37:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:104:"WPTavern: A WordPress Plugin That Helps Remove Access To The WordPress Dashboard From Non Administrators";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26450";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:252:"http://wptavern.com/a-wordpress-plugin-that-helps-remove-access-to-the-wordpress-dashboard-from-non-administrators?utm_source=rss&utm_medium=rss&utm_campaign=a-wordpress-plugin-that-helps-remove-access-to-the-wordpress-dashboard-from-non-administrators";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3131:"<p>Have you ever wanted to remove access to the WordPress dashboard for a user but didn&#8217;t want to touch any code to do it? <a title="http://wordpress.org/plugins/remove-dashboard-access-for-non-admins/" href="http://wordpress.org/plugins/remove-dashboard-access-for-non-admins/">Remove Dashboard Access</a> by <a title="http://werdswords.com/" href="http://werdswords.com/">Drew Jaynes</a> makes it an easy process. After activating the plugin, I found it difficult to locate where the configuration settings are. The settings are at the bottom of the <strong>Settings &gt; Reading</strong> page. I also discovered a quick link to the settings on the plugins management screen.</p>
<p>You can remove access based on a user&#8217;s capability, or if they&#8217;re part of the Administrator, Author, or Editor roles. This is great if you don&#8217;t have any users assigned to roles provided by plugins like <a title="https://wordpress.org/plugins/edit-flow/" href="https://wordpress.org/plugins/edit-flow/">Edit Flow</a> or if you created custom roles though the <a title="https://wordpress.org/plugins/members/" href="https://wordpress.org/plugins/members/">Members</a> plugin. If a custom role has a specific capability separate from other roles, you can use the Limit By Capability feature.</p>
<div id="attachment_26456" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/RemoveDashboardAccessOptions.png" rel="prettyphoto[26450]"><img class="size-full wp-image-26456" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/RemoveDashboardAccessOptions.png?resize=782%2C501" alt="Settings To Control Who Has Access To The Dashboard" /></a><p class="wp-caption-text">Settings To Control Who Has Access To The Dashboard</p></div>
<p>For those that don&#8217;t have access, you can redirect them to a specific URL. You can also choose whether or not they can use the dashboard to edit their profile. Last but not least, there&#8217;s a box provided to create a custom login message. The plugin removes access to some of the built-in WordPress Toolbar menu items by default. However, if you want to remove toolbar menus from other plugins, you can follow the guide on the plugin&#8217;s <a title="http://wordpress.org/plugins/remove-dashboard-access-for-non-admins/other_notes/" href="http://wordpress.org/plugins/remove-dashboard-access-for-non-admins/other_notes/">other notes page</a>.</p>
<p>Remove Dashboard Access works great for its intended purpose but if you need more granular control over which roles you can remove access from, you&#8217;ll need to look elsewhere. The plugin can be found on the <a title="http://wordpress.org/plugins/remove-dashboard-access-for-non-admins/" href="http://wordpress.org/plugins/remove-dashboard-access-for-non-admins/">WordPress plugin directory</a> or <a title="https://github.com/DrewAPicture/remove-dashboard-access" href="https://github.com/DrewAPicture/remove-dashboard-access">on Github</a>. Jaynes openly invites pull requests.</p>
<p>Do you know of a plugin that has a similar feature set but supports custom roles?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Jul 2014 21:38:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"WPTavern: WPCore: Create WordPress Plugin Collections and Install Them in One Click";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26414";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:208:"http://wptavern.com/wpcore-create-wordpress-plugin-collections-and-install-them-in-one-click?utm_source=rss&utm_medium=rss&utm_campaign=wpcore-create-wordpress-plugin-collections-and-install-them-in-one-click";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5049:"<p><a href="http://wordpress.org/plugins/wpcore/" target="_blank">WPCore</a> landed in the WordPress plugin repository this week. The plugin extends WordPress to interact with the new <a href="http://wpcore.com/" target="_blank">WPCore</a> service that allows you to create and manage plugin collections. The new WPCore plugin lets you bulk install all the plugins from any collection in just one click. The service was created by <a href="http://stueynet.com/" target="_blank">Stuart Starr</a>, an application developer with a penchant for launching what he calls &#8220;brand new and relatively useless web services.&#8221; In this case he may have actually launched a useful one.</p>
<p>Your average WordPress site needs at least a few plugins to add basics like contact forms, SEO, galleries, etc. More specialized sites can require a dozen or more related plugins in order to provide more complex functionality like e-commerce, social networking, forums, or event management. This is where having a collection ready to install can save you some time.</p>
<p>Once you sign up for the free service, you can start creating your own public or private collections on WPCore.com. Private collections will not appear in the collections directory.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/create-new-collection.jpg" rel="prettyphoto[26414]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/create-new-collection.jpg?resize=606%2C354" alt="create-new-collection" class="aligncenter size-full wp-image-26429" /></a></p>
<p>Start typing in plugin names or slugs to add them to the collection. The search box autosuggests plugins as you type:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/plugin-search.jpg" rel="prettyphoto[26414]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/plugin-search.jpg?resize=747%2C602" alt="plugin-search" class="aligncenter size-full wp-image-26431" /></a></p>
<p>As you can see above, each plugin collection is assigned its own unique key. Once you&#8217;ve added all the plugins you want to your collection, you can then paste this key into the WPCore settings page:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/add-key.png" rel="prettyphoto[26414]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/add-key.png?resize=900%2C407" alt="add-key" class="aligncenter size-full wp-image-26436" /></a></p>
<p>This will pull up all the plugins in the collection and link to a bulk install page in the admin:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/bulk-install.png" rel="prettyphoto[26414]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/bulk-install.png?resize=1025%2C408" alt="bulk-install" class="aligncenter size-full wp-image-26437" /></a></p>
<p>The handy thing is that you can grab the key from any collection to bulk install the plugins; it doesn&#8217;t have to be one that you created. You can browse the WPCore <a href="http://wpcore.com/collections" target="_blank">Collections</a> directory to find other public collections that users have already shared.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/collections.jpg" rel="prettyphoto[26414]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/collections.jpg?resize=972%2C548" alt="collections" class="aligncenter size-full wp-image-26423" /></a></p>
<p>Collections can be shared, edited and/or deleted, and made private at any time. The concept is very similar to what the <a href="http://wptavern.com/how-to-bulk-install-all-your-favorite-wordpress-plugins" target="_blank">WP Install Profiles</a> plugin provides with its <a href="http://plugins.ancillaryfactory.com/">corresponding service</a>. The <a href="http://wptavern.com/rolling-your-own-wordpress-with-wproller" target="_blank">WP Roller</a> service is another app that attempts to do the same thing but also allows you to customize a few extra settings in the process. So far, none of these services have grown to become mainstream tools for WordPress developers.</p>
<p>The WPCore app was built with <a href="http://laravel.com/" target="_blank">Laravel</a> and <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a>. After testing the app and the plugin, I can confirm it is user-friendly and provides a super fast way to install a long list of plugins. Making the most of WPCore requires having your collections set up already and a necessity to install the same plugins on multiple sites.</p>
<p>For those building WordPress sites regularly for clients, the tool can be a real time saver. Once your collection is set, you no longer have to spend time trying to remember all the plugins you need for setting up new sites. It&#8217;s also an easy way to share your recommendations with new users and other developers. Check out <a href="http://wpcore.com/" target="_blank">WPCore</a> and let us know if this is a service you&#8217;re likely to use.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Jul 2014 21:09:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WordPress.tv: Bolette Obbekær: Designtendenser 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36614";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wordpress.tv/2014/07/15/bolette-obbekaer-designtendenser-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:652:"<div id="v-1oeinlph-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36614/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36614/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36614&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/15/bolette-obbekaer-designtendenser-2014/"><img alt="Bolette Obbekær: Designtendenser 2014" src="http://videos.videopress.com/1oeinlph/video-085b37d644_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Jul 2014 15:55:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:100:"WordPress.tv: Peter Nemčok:  2013 – rok, v ktorom sa WordPress stal jednotkou už aj na Solvensku";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36585";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:109:"http://wordpress.tv/2014/07/15/peter-nemcok-2013-rok-v-ktorom-sa-wordpress-stal-jednotkou-uz-aj-na-solvensku/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:744:"<div id="v-zehOrzcb-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36585/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36585/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36585&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/15/peter-nemcok-2013-rok-v-ktorom-sa-wordpress-stal-jednotkou-uz-aj-na-solvensku/"><img alt="Peter Nemčok: 2013 &#8211; rok, v ktorom sa WordPress stal jednotkou  už aj na Solvensku" src="http://videos.videopress.com/zehOrzcb/video-d20b1ef572_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Jul 2014 15:19:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WordPress.tv: Travis Totz: Designing for Interaction";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36420";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.tv/2014/07/15/travis-totz-designing-for-interaction-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:654:"<div id="v-tYGpHGjV-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36420/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36420/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36420&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/15/travis-totz-designing-for-interaction-2/"><img alt="Travis Totz: Designing for Interaction" src="http://videos.videopress.com/tYGpHGjV/video-afcb9b7f01_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Jul 2014 15:04:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: New Yorker on WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43932";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2014/07/new-yorker-on-wp/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:688:"<p>The New York Times writes about how <a href="http://www.nytimes.com/2014/07/09/business/media/the-new-yorker-alters-its-online-strategy.html">The New Yorker is overhauling its design and online presence</a>, including experimenting with paywalls and this wonderful nugget:</p>
<blockquote><p>The new site, designed to be cleaner, with new typefaces, will be based on the WordPress publishing system. It is expected to be easier to navigate for mobile users — among the fastest-growing segments of the readership.</p></blockquote>
<p>The New Yorker is one of my top 3 favorite publications in the world, and I&#8217;m very excited they&#8217;ll be using WP for their next chapter.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Jul 2014 13:56:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: Hybrid Core 2.0 Adds Composer Support, Removes Widgets From Framework";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26332";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:200:"http://wptavern.com/hybrid-core-2-0-adds-composer-support-removes-widgets-from-framework?utm_source=rss&utm_medium=rss&utm_campaign=hybrid-core-2-0-adds-composer-support-removes-widgets-from-framework";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5132:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/hybrid-core1.png" rel="prettyphoto[26332]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/hybrid-core1.png?resize=700%2C285" alt="hybrid-core" class="aligncenter size-full wp-image-26407" /></a></p>
<p>Theme Hybrid released <a href="http://themehybrid.com/weblog/hybrid-core-version-2-0" target="_blank">Hybrid Core 2.0</a> today after many months in development. The framework, created by Justin Tadlock, powers this site and many other WordPress sites on the web. <a href="http://themehybrid.com/weblog/hybrid-core-theme-framework-version-1-0" target="_blank">Version 1.0</a> was first released in October 2010, built from the engine that made up the base of Tadlock&#8217;s popular Hybrid Theme.</p>
<p>Since that time, <a href="http://themehybrid.com/hybrid-core" target="_blank">Hybrid Core</a> has been downloaded hundreds of thousands of times. Version 2.0 includes <a href="https://github.com/justintadlock/hybrid-core/commits/2.0.0" target="_blank">more than 200 commits</a> and several major changes that will be important for users and theme developers to know about.</p>
<h3>Composer Support</h3>
<p>Tadlock credits Andrey Savchenko (<a href="http://www.rarst.net/" target="_blank">@Rarst</a>) with helping to add <a href="https://getcomposer.org/" target="_blank">Composer</a> support to Hybrid Core. Composer is a dependency manager for PHP that operates on a project-by-project basis by pulling in all the required libraries to manage them in one place.</p>
<p>Hybrid Core now includes a <a href="https://github.com/justintadlock/hybrid-core/blob/master/composer.json" target="_blank">composer.json</a> file and those familiar with Composer can find the <a href="https://packagist.org/packages/justintadlock/hybrid-core" target="_blank">package link</a> on Packagist. Please note that using Composer is optional and not required for using Hybrid Core. For more information on getting started, check out @Rarst&#8217;s mini guide on using <a href="http://composer.rarst.net/" target="_blank">Composer with WordPress</a>.</p>
<h3>Trimming the Framework</h3>
<p>Hybrid Core 2.0 is a return to the basics of WordPress theme development in that it further separates functionality from presentation. Tadlock took a blade to framework and sliced out a sizeable chunk of legacy code, opting to support accompanying plugins to keep the core lean.</p>
<p>Widgets have been <a href="http://themehybrid.com/weblog/where-oh-where-have-my-widgets-gone" target="_blank">completely removed</a> in favor of the <a href="http://themehybrid.com/plugins/widgets-reloaded" target="_blank">Widgets Reloaded</a> plugin, which Tadlock recommends users install if they want to keep their widgets. Entry Views was converted into a WordPress <a href="http://themehybrid.com/weblog/entry-views-wordpress-plugin" target="_blank">plugin</a> in order to help keep the framework more modular. Several extensions were dropped entirely, along with post and comment-related template shortcodes and deprecated functions prior to 2.0.</p>
<p>Theme developers will be particularly interested in the new attribute system which allows for more flexibility than using body_class(). It includes built-in support for ARIA and <a href="http://schema.org/" target="_blank">Schema.org microdata</a>.</p>
<p>Hybrid Core 2.0 also organizes all of the framework&#8217;s template tags into a /functions directory and introduces many new tags for theme authors. &#8220;Most of them are on my WordPress &#8216;wish list,&#8217;&#8221; Tadlock said. &#8220;So I hope to eventually see them added to core WordPress. They are functions that I believe are hugely beneficial to theme authors.&#8221;</p>
<p>Overall, Tadlock was able reduce 66 KB from the Hybrid Core zip file, while adding new features for theme developers at the same time. Naturally, if your site was making use of anything that was removed, an update to 2.0 may require you to add a new plugin or make transitions in your theme&#8217;s code. You&#8217;ll want to review the specifics outlined in the release <a href="http://themehybrid.com/weblog/hybrid-core-version-2-0" target="_blank">announcement</a>.</p>
<p>Theme Hybrid has always been on the forefront of defining and redefining WordPress theme frameworks and the relationship between parent/child themes. Tadlock is a purist when it comes to WordPress theme development best practices and his commitment to <a href="http://wptavern.com/why-wordpress-theme-developers-are-moving-functionality-into-plugins" target="_blank">data portability</a> is admirable in a theme market where many of the largest sellers are only there to make a buck.</p>
<p>Hybrid Core 2.0 is a much leaner version of the framework that theme developers have been working with for years. As documentation is still being written, you&#8217;ll need to take it out of the box and explore the code to find all the new goodies. <a href="http://themehybrid.com/hybrid-core" target="_blank">Hybrid Core 2.0</a>, like all Theme Hybrid plugins and themes, is available to download for free.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Jul 2014 03:45:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"WPTavern: WP Quick Install Script Offers a Fast Way to Install WordPress, Plugins, and Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26103";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:226:"http://wptavern.com/wp-quick-install-script-offers-a-fast-way-to-install-wordpress-plugins-and-themes?utm_source=rss&utm_medium=rss&utm_campaign=wp-quick-install-script-offers-a-fast-way-to-install-wordpress-plugins-and-themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4958:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/wp-quick-install.jpeg" rel="prettyphoto[26103]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/wp-quick-install.jpeg?resize=300%2C263" alt="wp-quick-install" class="alignright size-medium wp-image-26338" /></a></p>
<p><a href="http://wp-quick-install.com/" target="_blank">WP Quick Install</a> is an interesting new tool from Julio Potier, Jonathan Buttigieg, and Jean-Baptiste Marchand-Arvier, the folks behind <a href="http://wptavern.com/wp-rocket-launches-commercial-caching-plugin-for-wordpress" target="_blank">WP Rocket</a>. As part of supporting their commercial caching plugin, the WP Rocket team works extensively with clients. WP Quick Install is a tool they use internally and decided to share with the community.</p>
<p>Its creators claim that the script is the easiest way to install WordPress. You download the tiny script and then upload it to where you want your installation. The new installation screen allows you to add themes and plugins to your site as well as configure some of the most common settings. It even allows you to do a few extra handy things like auto-remove the default content created by WordPress, ie. page, post, comment, themes, etc.</p>
<p>&#8220;We set up a fresh WordPress installation almost every week, both for our clients and for testing purposes,&#8221; Marchand-Arvier told the Tavern. &#8220;It&#8217;s always the same (when we don&#8217;t have SSH): download the zip, unzip, upload via ftp, install our favorites plugins, remove the default content, etc. So we developed a tool to do this for us.&#8221;</p>
<p>Marchand-Arvier said that the team created the tool for the sake of convenience and wanted to share it to give back to the community. He confirmed that they have no plans to build a commercial product around it but simply want to release as many free plugins and scripts as they can while developing for WordPress.</p>
<h3>Bulk Install Plugins and Themes While Installing WordPress</h3>
<p>In addition to all the usual database details, WP Quick Install allows you to select search engine privacy settings, media thumbnail sizes, revision and autosave settings, enable debug mode, and disable the theme and plugin editors.  Any theme that you include in the install folder can also be automatically activated:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/theme-info.png" rel="prettyphoto[26103]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/theme-info.png?resize=736%2C298" alt="theme-info" class="aligncenter size-full wp-image-26345" /></a></p>
<p>The automatic plugin installation part of the script is likely to save users the most time. It allows you to specify extensions by their slugs and automatically activate them upon installation:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/extensions-information.png" rel="prettyphoto[26103]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/extensions-information.png?resize=721%2C337" alt="extensions-information" class="aligncenter size-full wp-image-26347" /></a></p>
<p>WP Quick Install may seem like a long installation form to fill out, but the good news is that you can include a data.ini file to pre-populate the installation form or to generate content (posts, pages, etc).</p>
<h3>Multisite Support Coming Soon</h3>
<p>In the future, the WP Rocket team plans to add network creation to the script. &#8220;We want to keep it simple, but of course we definitely want to improve this tool,&#8221; Marchand-Arvier said. &#8220;We are currently working on multisite deployment. The script is on <a href="https://github.com/GeekPress/WP-Quick-Install" target="_blank">GitHub</a> and it&#8217;s open to contributions.&#8221;</p>
<p>The tool is convenient if you prepare a data.ini file to pre-populate the installation form, but its primary shortcoming is that it doesn&#8217;t let you select the language before doing anything else. The script uses the WordPress 4.0 language API to manage the dropdown selection, allowing you to install in any language. However, it doesn&#8217;t automatically change the language in the installation process. This forces the user to complete the lengthy form in English. Hopefully, this aspect of the script will be improved in the next version.</p>
<p>The WP Rocket team created <a href="http://wp-quick-install.com/" target="_blank">WP Quick Install</a> chiefly for novice developers. &#8220;We aren&#8217;t pretending to replace the classic WordPress installation,&#8221; Marchand-Arvier said. &#8220;But today we believe that it&#8217;s the easiest way to install WordPress, especially if you don&#8217;t use WP-CLI or wget to install.&#8221; Check out the demo video below and let us know in the comments if you think the script can help you speed up your installations.</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Jul 2014 20:48:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: Critical Security Update For WPTouch, Users Should Update Immediately";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26304";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:200:"http://wptavern.com/critical-security-update-for-wptouch-users-should-update-immediately?utm_source=rss&utm_medium=rss&utm_campaign=critical-security-update-for-wptouch-users-should-update-immediately";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2209:"<p>First <a title="http://blog.sucuri.net/2014/07/disclosure-insecure-nonce-generation-in-wptouch.html" href="http://blog.sucuri.net/2014/07/disclosure-insecure-nonce-generation-in-wptouch.html">reported by Sucuri</a>, the <a title="https://wordpress.org/plugins/wptouch/" href="https://wordpress.org/plugins/wptouch/">WPTouch plugin</a> has a dangerous security vulnerability and users are encouraged to update immediately. WPTouch is used to quickly add mobile support to websites and has over 5 million downloads making it one of the most popular plugins in the WordPress plugin directory.</p>
<div id="attachment_26317" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/WPTouchFeaturedImage.png" rel="prettyphoto[26304]"><img class="size-full wp-image-26317" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/WPTouchFeaturedImage.png?resize=739%2C243" alt="WPTouch Plugin Header" /></a><p class="wp-caption-text">WPTouch Plugin Header</p></div>
<p>&nbsp;</p>
<p>According to Sucuri, WPTouch incorrectly uses the &#8220;<em>admin_init</em>&#8221; hook which can lead to users without the correct capabilities to upload malicious files to the server. Mailpoet, another popular plugin <a title="http://wptavern.com/wordpress-mailpoet-plugin-security-vulnerability-immediate-update-recommended" href="http://wptavern.com/wordpress-mailpoet-plugin-security-vulnerability-immediate-update-recommended">recently suffered</a> from the same type of security issue. Taking advantage of the bug is a simple two-step process.</p>
<blockquote><p>All an attacker had to do in order to compromise a vulnerable website was to:</p>
<ol>
<li>Log­in and get his nonce via wp-admin</li>
<li>Send an AJAX file upload request containing the leaked nonce and his backdoor</li>
</ol>
<p>So long story short – don’t only use nonces to protect sensitive methods, always add functions such as “current_user_can()” or the likes to confirm a user’s right to do something.</p></blockquote>
<p>The vulnerability only affects sites that have registration enabled but you should update regardless. Users should already see an upgrade notification in the dashboard.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Jul 2014 16:45:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: Baskerville: A Free WordPress Theme for Hoarders";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26215";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:158:"http://wptavern.com/baskerville-a-free-wordpress-theme-for-hoarders?utm_source=rss&utm_medium=rss&utm_campaign=baskerville-a-free-wordpress-theme-for-hoarders";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3177:"<p><a href="http://wordpress.org/themes/baskerville" target="_blank">Baskerville</a> is a new masonry grid style WordPress theme available from designer <a href="http://wptavern.com/anders-noren-on-achieving-simplicity-in-wordpress-theme-design" target="_blank">Anders Norén</a>. His popular <a href="http://wordpress.org/themes/hemingway" target="_blank">Hemingway</a> theme has received more than 60,000 downloads on WordPress.org and is also offered on <a href="http://theme.wordpress.com/themes/hemingway-rewritten/" target="_blank">WordPress.com</a>. Baskerville was created to showcase many different types of content, hence its tagline: &#8220;A WordPress Theme for Hoarders.&#8221;</p>
<p>The theme bears Norén&#8217;s trademark minimalist style, is responsive and retina-ready. It includes support for all nine post formats with content-specific styles for videos, galleries, images, quotes, links, etc.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/baskerville.png" rel="prettyphoto[26215]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/baskerville.png?resize=880%2C660" alt="baskerville" class="aligncenter size-full wp-image-26276" /></a></p>
<p>Post meta is attractively styled and placed at the bottom of the content, so it doesn&#8217;t clutter up the page and detract from the main event. It also includes an author box with social links.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/quote-format.jpg" rel="prettyphoto[26215]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/quote-format.jpg?resize=725%2C845" alt="quote-format" class="aligncenter size-full wp-image-26297" /></a></p>
<p>Baskerville customization options can be found in the customizer, including:</p>
<ul>
<li>Custom logo upload</li>
<li>Background color</li>
<li>Custom header image(s) and ability to randomize the display</li>
<li>Background image</li>
<li>Two widget areas (sidebar and footer)</li>
</ul>
<p>Check out a <a href="http://andersnoren.se/themes/baskerville/" target="_blank">live demo</a> of Baskerville to resize your browser window to see how smoothly it responds to different screen sizes.</p>
<p>The theme also adds three custom widgets to display videos, Flickr, Dribbble shots and like functionality via the <a href="http://www.themezilla.com/plugins/zillalikes/" target="_blank">ZillaLikes</a> plugin. Pages can be customized via four different templates, including full-width, no sidebar, archives and a contributors template which showcases writers with avatars, descriptions and social links.</p>
<p>Baskerville includes a Swedish/svenska translation but the code is translation-ready so you can easily translate it into your own language.</p>
<p>If you&#8217;re enthusiastic about using post formats, then <a href="http://wordpress.org/themes/baskerville" target="_blank">Baskerville</a> may be the theme for you. It works nicely for magazines or personal blogs that regularly post multimedia content. Install it via your WordPress admin theme browser or <a href="http://wordpress.org/themes/baskerville" target="_blank">download</a> it directly from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Jul 2014 16:15:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WordPress.tv: Peter Lauge: Avancerede WordPress-løsninger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36605";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://wordpress.tv/2014/07/14/peter-lauge-avancerede-wordpress-losninger-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:665:"<div id="v-RaLiPRyJ-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36605/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36605/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36605&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/14/peter-lauge-avancerede-wordpress-losninger-2/"><img alt="Peter Lauge: Avancerede WordPress-løsninger" src="http://videos.videopress.com/RaLiPRyJ/video-45325fb52b_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Jul 2014 15:57:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"Post Status: Chris Coyier on WordPress, business, and building the web";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=6874";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:112:"http://www.poststat.us/chris-coyier-interview/?utm_source=rss&utm_medium=rss&utm_campaign=chris-coyier-interview";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:12629:"<p><img class="aligncenter size-large wp-image-6881" src="http://www.poststat.us/wp-content/uploads/2014/07/chris-coyier-752x406.jpg" alt="chris-coyier" width="752" height="406" />Chris Coyier is not a stranger to most of us web workers. He&#8217;s a designer at <a title="CodePen" href="http://codepen.io">CodePen</a>, a writer at <a title="CSS-Tricks" href="http://css-tricks.com">CSS-Tricks</a>, and a podcaster at <a title="ShopTalk Podcast" href="http://shoptalkshow.com">ShopTalk</a>.</p>
<p>He uses WordPress on all three of his primary projects. For years, Chris has been a consistent advocate for the platform. He develops his own websites with WordPress, but his day-to-day interactions are as a user.</p>
<p>Chris brings a unique perspective, I believe. He did some client work early in his career, but he&#8217;s been more involved in SaaS projects and membership websites; his current membership websites are on WordPress (CSS-Tricks) and Ruby on Rails (CodePen).</p>
<p>I asked Chris about his projects, his perspective on various aspects of WordPress, and the community around it. I enjoyed learning from him, and I hope you do too:</p>
<!--[if lt IE 9]><script>document.createElement(\'audio\');</script><![endif]-->
<a href="http://s3.amazonaws.com/PostStatus/DraftPodcast/chris-coyier-post-status-draft.mp3">http://s3.amazonaws.com/PostStatus/DraftPodcast/chris-coyier-post-status-draft.mp3</a>
<p><a href="http://s3.amazonaws.com/PostStatus/DraftPodcast/chris-coyier-post-status-draft.mp3">Direct Download</a></p>
<h3>What have you learned from working on membership websites?</h3>
<blockquote><p> It&#8217;s just a good dang business idea.</p></blockquote>
<p>Chris was sold on the idea of membership websites from his tenure at <a title="Wufoo" href="http://www.wufoo.com/">Wufoo</a> and <a title="SurveyMonkey" href="https://www.surveymonkey.com/">SurveyMonkey</a> (where he worked once they acquired Wufoo).</p>
<p>He uses Pippin Williamson&#8217;s <a href="https://pippinsplugins.com/restrict-content-pro-premium-content-plugin/">Restrict Content Pro</a> for managing <a title="The Lodge" href="http://css-tricks.com/lodge/">The Lodge</a> on CSS-Tricks. At CodePen, they spend time thinking about pricing, churn, and other membership metrics.</p>
<p>They talk about some of these things (and much more) on the <a title="CodePen Radio" href="http://blog.codepen.io/radio/">CodePen Radio</a> podcast &#8212; an awesome podcast for anyone interested in SaaS, not just CodePen.</p>
<h4>Delivering value</h4>
<p>Another aspect Chris noted about membership websites is how it makes you want to continually deliver value for customers. He always wants to make people feel like they&#8217;re getting excellent features and value for the price of their membership.</p>
<p>Another thing he and the CodePen team are learning is prioritizing feature requests. When you are building for members, you want to build features members want; and sometimes that goes against other fixes that are less glamorous. So they are consistently trying to balance time spent on customer-facing features versus behind the scenes development.</p>
<h4>Build the feature, get the reward</h4>
<p>Chris talked about how important it is for him to build something, then be rewarded for the work he does, versus selling something and then having to build the feature for it.</p>
<p>He experience this with his big <a href="https://www.kickstarter.com/projects/chriscoyier/screencasting-a-complete-redesign">Kickstarter</a> project for a CSS-Tricks redesign a couple of years ago, and said that mentality was really difficult for him.</p>
<h3>What do you appreciate more now about WordPress, after using other software?</h3>
<p>WordPress comes with a lot of built-in features that many of us (I do at least) may take for granted. Need a user system? Check. Need comments? Check. Need categorization? Check.</p>
<p>Building CodePen, Chris is able to appreciate (even more than before) just how powerful WordPress is and how much thought goes into every feature.</p>
<p>We dove into something seemingly simple as an example: tags. It turns out that something even that simple takes a lot of thought, consideration, and user experience considerations.</p>
<blockquote><p>What it ends up as, is something you&#8217;ll have to iterate on for years to get anywhere close to how good the WordPress one works already. And that&#8217;s like the tiniest thing we could think about. Think about the login system, or something else.</p></blockquote>
<p>So his advice was to focus on simplicity and decisions when building features, because required effort grows rapidly as a feature gets more complicated.</p>
<h3>How would you compare the WordPress community to other web communities?</h3>
<p>Chris has exposure to a much broader web community than I do. I&#8217;m pretty locked into the WordPress bubble. He sees the Ruby on Rails world, the more generic web world, and attends and speaks at a slew of non-WordPress conferences every year.</p>
<p>Even though he says he&#8217;s mostly in a WordPress bubble himself (he&#8217;s not exactly attending Drupal conferences, he notes), he thinks that the WordPress community is pretty top-notch, and hasn&#8217;t seen other communities that are &#8220;better&#8221; than the WordPress community.</p>
<blockquote><p>There&#8217;s definitely no other CMS that I&#8217;m jealous of that community.</p></blockquote>
<h3>What questions about WordPress are you always seeing on the ShopTalk Podcast</h3>
<p>Chris and his co-host Dave Rupert (seriously, <a href="https://twitter.com/davatron5000">follow Dave</a> and gain laughs and knowledge in life) get a lot of questions about WordPress on the ShopTalk Podcast. Some of these questions are repeated pretty frequently, and they see trends of common issues.</p>
<h4>Working locally and syncing remotely</h4>
<p><span id="more-6874"></span></p>
<p>For WordPress, the most common questions tend to come around syncing the local development environment with the live environment. They&#8217;ve been recommending <a title="WP Migrate DB Pro" href="https://deliciousbrains.com/wp-migrate-db-pro/">WP Migrate DB Pro</a> for people trying to get around that, though Chris says he doesn&#8217;t think it&#8217;s perfect for huge websites like CSS-Tricks.</p>
<p>I think, to a degree, the common confusion is logical. WordPress development is really centered around three different layers of &#8220;stuff&#8221;: the content (posts, pages, etc), the files in the directory, and the site management database options. I think there is plenty of room for confusion when it&#8217;s not easy to decouple website management with website content, from a database perspective.</p>
<h4>Learning more about WordPress through the lens of a different audience</h4>
<p>I used this segment to talk about other confusing aspects of WordPress. We talked about database management, the degree of PHP knowledge required for WordPress theming, using pre-processors in distributed versus custom themes, responsive images, and the asset-itis of many WordPress websites that utilize plugins that each load their own scripts and styles.</p>
<p>Regardless of the specific issues people are having, I find tremendous value listening to ShopTalk &#8212; which is not as hardcore of a WordPress audience as I have here &#8212; where the trends of people&#8217;s struggles help reveal real struggles that perhaps we could build better tools for in WordPress.</p>
<p>It&#8217;s also worth noting that some of the &#8220;struggles&#8221; we talked about are very modern struggles, and WordPress has been around for over eleven years. WordPress iterates pretty quickly and does a great job of supporting modern web features, but it&#8217;s rarely immediate, especially in terms of core support. But plugin support and the shear number of people innovating on top of WordPress is significant and awesome.</p>
<h3>Just build websites!</h3>
<blockquote><p>So many people want to be told what to do and what to learn next. That&#8217;s for sure the #1 question on ShopTalk.</p></blockquote>
<p>In the face of lots of new and changing technology, Chris is often asked about what to do first, or what to do next. He and Dave have a core <a href="http://shoptalkshow.com/mantra/">mantra at ShopTalk</a> to encourage people to &#8220;just build websites!&#8221;</p>
<blockquote><p>The things that you learn will happen as a result of building those websites and things for other people.</p></blockquote>
<p>The degree of paralysis by analysis they see is significant, and Chris and Dave hope that people will let their experiences guide them versus a to-do list of things they must learn today.</p>
<h4>You&#8217;re desirable</h4>
<p>Another note is that pretty much everyone has something they can do to provide value to others. People surely know something from a tooling perspective that&#8217;s worthwhile; even sans-modern tools, basic knowledge of HTML and CSS &#8212; the building blocks of the web &#8212; could be a great asset to lots of business.</p>
<p>Even more important than tooling though, is the ability to solve problems. Chris used an example of a business that sells wrenches. If you can help a business that sells wrenches to sell more wrenches, then you are able to provide that business a lot of value; so focus on helping businesses do what they do better.</p>
<h4>Learn by sharing</h4>
<p>I admire Chris&#8217; degree of sharing what he&#8217;s learning, through ShopTalk, CodePen Radio, and for years on CSS-Tricks.</p>
<p>He doesn&#8217;t do anything special to write about what he learns. He keeps his drafts right there in WordPress. He doesn&#8217;t take special notes. He just writes, and he often writes about what he&#8217;s learning.</p>
<p>Over time he&#8217;s been able to refine his writing and learn what to expect, as far as feedback goes. But at the core he just writes, and through that writing he&#8217;s been able to grow his own audience and get better at everything else he&#8217;s doing professionally.</p>
<h3>Staying consistent and avoiding burnout</h3>
<p>I was curious what Chris has done to stay so consistent online and avoid burnout. It seems to me that a lot of people get temporarily motivated and quickly disenchanted.</p>
<p>I&#8217;ve learned in my own experience with the web that any measure of success takes lots and lots of consistent effort. Chris hasn&#8217;t done a lot to think about avoiding burnout, but figures there are some things he subconsciously does to stay motivated.</p>
<p>That may be taking extended breaks from the web and disconnecting for a trip to the woods, or shorter breaks just in the day like stopping and playing the banjo for a few minutes.</p>
<h3>Stay in touch with Chris</h3>
<p>At the end of every episode of ShopTalk, Chris and Dave give guests an opportunity to plug whatever they want.</p>
<p>Chris&#8217; plug for our interview was to advise folks to take some time off from building their own product and instead go into their issues list and clean up after themselves and their project &#8212; which is what Chris and team are doing at CodePen right now.</p>
<p>He also noted that nothing would make him happier than folks going <a href="http://codepen.io/pro">Pro on CodePen</a>. If you teach, interact with others, or want a way to store private pens, you should definitely check it out. And it&#8217;s affordable too, at only $75 for the year.</p>
<p>While he didn&#8217;t take the opportunity to plug much of his own stuff, you should definitely still check out his various projects. I&#8217;ve learned a ton from Chris since I started my own journey on the web. If my learning journey on the web were a university, I&#8217;ve definitely taken multiple classes from CSS-Tricks and the ShopTalk Show. Chris&#8217; business is built on a three-legged stool right now. Check them out:</p>
<ul>
<li><a href="http://codepen.io">CodePen</a> &#8211; a playground for the front-end side of the web.</li>
<li><a href="http://shoptalkshow.com/">ShopTalk Show</a> &#8211; a podcast about front-end web design (and sound effects).</li>
<li><a href="http://css-tricks.com/">CSS-Tricks</a> &#8211; where the whole internet learns CSS.</li>
</ul>
<p>Also check out <a href="http://chriscoyier.net/about/">Chris&#8217; fun about page</a> with his life&#8217;s timeline and <a href="https://twitter.com/chriscoyier">follow him on Twitter</a>.</p>
<hr />
<p>I&#8217;d like to thank Chris for the time he spent with me, and I hope that if you enjoyed this interview and write-up, that you&#8217;ll share it!</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Jul 2014 15:43:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Matt: Ibrahim Maalouf Wowed Me";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43926";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:37:"http://ma.tt/2014/07/ibrahim-maalouf/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2219:"<p>One of the most surprising performances I saw at the North Sea Jazz festival was a French-Lebanese trumpet player named Ibrahim Maalouf. He plays a trumpet with a special additional fourth valve &#8212; three is standard &#8212; that allows him to more easily play <a href="http://en.wikipedia.org/wiki/Arabic_maqam">Arabic maqams</a> or scales with quarter tone and three quarter tone intervals along with <a href="http://en.wikipedia.org/wiki/Equal_temperament">equal temperament western ones</a>, like <a href="http://en.wikipedia.org/wiki/Don_Ellis">Don Ellis</a>. He also has a way of playing that sounds most like singing in his inflections and vibrato.</p>
<p>This is the best video I could find of one song he did called &#8220;Beirut,&#8221; and I&#8217;m amazed it only has 475 views. It&#8217;s worth 12 minutes out of your day, especially when it amps up at the end.</p>
<p><span class="embed-youtube"></span></p>
<p class="p1"><span class="s1">The only word for the crowd was &#8220;pandemonium&#8221; &#8212; I’ve never seen a jazz audience react to music like that; it reminded me of the</span> <a href="http://en.wikipedia.org/wiki/Ellington_at_Newport#The_Gonsalves_solo">famous Duke Ellington / Paul Gonsalves performance and the riot that followed</a>.</p>
<p>The audience on Saturday went totally bonkers, and the band did some even wilder songs to close including with jazz bagpipe (gaita?), which reminded me of <a href="http://www.cristinapato.com/en/">Cristina Pato</a>. Here&#8217;s a video of a similar end, but it&#8217;s a much more subdued crowd:</p>
<p><span class="embed-youtube"></span></p>
<p>Amazing music, and also a good reminder of the power of a live performance, where a great artist can feed off the audience and vice versa. I wouldn&#8217;t mind going to a few more jazz shows where people are unafraid to hoot and holler and move a bit.</p>
<p>If you ever have a chance to see <a href="http://www.ibrahimmaalouf.com/en/">Ibrahim Maalouf</a> live, I  recommend it. It looks like he uses WordPress for his site, too, which makes him doubly cool. <img src="http://i1.wp.com/s.ma.tt/blog/wp-includes/images/smilies/icon_smile.gif?w=604" alt=":)" class="wp-smiley" /></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Jul 2014 14:56:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WPTavern: FooGallery – A Free WordPress Gallery Plugin Built For Developers and Designers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26279";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:218:"http://wptavern.com/foogallery-a-free-wordpress-gallery-plugin-built-for-developers-and-designers?utm_source=rss&utm_medium=rss&utm_campaign=foogallery-a-free-wordpress-gallery-plugin-built-for-developers-and-designers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3054:"<p><a title="http://wordpress.org/plugins/foogallery/" href="http://wordpress.org/plugins/foogallery/">FooGallery</a> is a new free WordPress plugin aimed squarely at developers and designers. <a title="http://fooplugins.com/wordpress-gallery-plugin/" href="http://fooplugins.com/wordpress-gallery-plugin/">Developed by FooPlugins</a>, FooGallery utilizes much of the same image and gallery handling found within WordPress, providing an intuitive content creation and management experience. While the plugin is simple, it offers developers a <a title="http://docs.fooplugins.com/foogallery/actions-filters/" href="http://docs.fooplugins.com/foogallery/actions-filters/">ton of filters and hooks</a> to extend its functionality. Some of the core features include:</p>
<ul>
<li>Gallery custom post type</li>
<li>Use built-in media library to manage images</li>
<li>Drag-and-drop reordering of images</li>
<li>Built-in gallery templates</li>
<li>Built-in support for FooBox</li>
<li>NextGen importer tool</li>
</ul>
<p>FooGallery runs on an extension framework where different functionality is separated into different areas of the codebase. This keeps the core plugin lightweight, but still allows for the most flexibility. A built-in extension boilerplate generator makes it easy to create template or lightbox extensions. Although extensions can be hosted on the WordPress plugin directory, you&#8217;ll want to <a title="http://foo.gallery/submit-extension/" href="http://foo.gallery/submit-extension/">submit them</a> to them to the FooGallery website as well. Extensions that are accepted into the FooGallery directory will be listed in the Extensions tab within the plugin. Extensions can either be free or commercial.</p>
<div id="attachment_26283" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/FooGalleryExtensionBoilerplate.png" rel="prettyphoto[26279]"><img class="size-full wp-image-26283" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/FooGalleryExtensionBoilerplate.png?resize=1025%2C756" alt="FooGallery Boilerplate Generator" /></a><p class="wp-caption-text">FooGallery Boilerplate Generator</p></div>
<p><a title="http://docs.fooplugins.com/foogallery/foogallery-101/" href="http://docs.fooplugins.com/foogallery/foogallery-101/">Documentation for users</a> and <a title="http://docs.fooplugins.com/foogallery/foogallery-developers-101/" href="http://docs.fooplugins.com/foogallery/foogallery-developers-101/">developers</a> is available for free on the FooPlugins website. Since it&#8217;s a free plugin, support is handled via <a title="http://wordpress.org/support/plugin/foogallery" href="http://wordpress.org/support/plugin/foogallery">the WordPress.org support forums.</a> For those who want to contribute back to the project, you can find it <a title="https://github.com/fooplugins/foogallery" href="https://github.com/fooplugins/foogallery">on Github</a>.</p>
<p>If you need something lightweight compared to NextGen 2, you may want to consider using FooGallery.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Jul 2014 14:47:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: Founding Fathers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43934";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2014/07/founding-fathers/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:502:"<p>Kottke: <a href="http://kottke.org/13/08/the-surprising-ages-of-the-founding-fathers-on-july-4-1776">The surprising ages of the Founding Fathers on July 4, 1776</a>. While we&#8217;re talking about the Founding Fathers, Marc Andreessen thinks that the <a href="http://pmarcasays.golaun.ch/2014/07/14/founding-fathers-arguably-designed-us-system-specifically-to-be-dominated-by-moneyed-interests/">Founding Fathers Arguably Designed US System Specifically To Be Dominated By Moneyed Interests</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Jul 2014 13:18:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Akismet: Congratulations, Germany!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1618";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://blog.akismet.com/2014/07/14/congratulations-germany/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:789:"<p>The Akismet team would like to send a hearty congratulations to the Germany national football team for their victory over Argentina yesterday in the 2014 FIFA World Cup. Our own Akisbot was busy celebrating and showing his support last night.</p>
<p><img class="alignnone size-full wp-image-1621" src="http://akismet.files.wordpress.com/2014/07/akisbot-germany.jpg?w=700&h=525" alt="akisbot-germany" width="700" height="525" /></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1618/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1618/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1618&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Jul 2014 11:55:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Dan Hauk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"Post Status: Week in review: Beta 1, WooThemes is seeing double, and much more";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=6863";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:130:"http://www.poststat.us/week-in-review-wordpress-beta-1/?utm_source=rss&utm_medium=rss&utm_campaign=week-in-review-wordpress-beta-1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6295:"<p><img class="aligncenter size-large wp-image-6769" src="http://www.poststat.us/wp-content/uploads/2014/06/week-in-review1-752x300.jpg" alt="week-in-review" width="752" height="300" />Welcome to the third “<a href="http://www.poststat.us/category/week-in-review/">Week in Review</a>” on Post Status, where I hope to offer up some of the things you may have missed in the last week or so. It&#8217;s been a busy week, and there&#8217;s a lot to share, so let&#8217;s do it.</p>
<h3>WordPress 4.0 beta 1 is out</h3>
<p><a title="WordPress 4.0 Beta 1" href="http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">Beta 1 of WordPress 4.0</a> is out. This means that the feature list is frozen, and testing is underway. If you haven&#8217;t tested WordPress 4.0, now is a great time to be involved.</p>
<p>WordPress 4.0 is going to be an excellent release. There are a number of nice new features slated, including language selection upon install (a huge feature), an <a href="http://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/">improved customizer experience</a>, new media views, a new plugins experience in the admin, and an awesome scroll effect in the editor that makes writing so much better.</p>
<p>I just have to tease the scrolling:</p>
<div class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<a href="https://i.cloudup.com/2ndNE9tCzE.mp4">https://i.cloudup.com/2ndNE9tCzE.mp4</a></div>
<p>Thanks to <a href="https://twitter.com/kovshenin/status/487176276055056384">Konstantin Kovshenin</a> for the video.</p>
<p>You can check out more about <a title="WordPress 4.0 Beta 1" href="http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">Beta 1 on the WordPress release post</a>, and do give it a spin with your themes and plugins to help test for bugs.</p>
<h3>WooThemes has doubled revenues in the last year</h3>
<p>WooThemes celebrated their sixth birthday last week. But I think they <a title="Six Years of Woo" href="http://www.woothemes.com/2014/07/six-years/">buried the lede in the post</a>. Included in the celebratory post was the note that they&#8217;ve gone from 30 to 40 employees, doubled their revenues, and tripled their profit rates in the last year.</p>
<p>That&#8217;s some serious growth, and I&#8217;m sure mostly on the back of WooCommerce. As readers know (I love linking this post), WooCommerce is <a title="Interview with Mark Forrester, co-founder of WooThemes" href="http://www.poststat.us/interview-mark-forrester-co-founder-woothemes/">now over 80% of their revenue</a>, and probably more now.</p>
<h3>Bye bye, bacon</h3>
<p>Sadly, <a href="http://wpbacon.com/">WP Bacon</a> is done for. The podcast was a fun one, and the blog was pretty good too, but Rob and Ozzy are moving on. The domain got hammered a while back, and the effort to recover the site&#8217;s value just wasn&#8217;t worth the effort, so the Bacon is gone.</p>
<p>No fear though, the folks behind it aren&#8217;t going anywhere. You can follow <a href="http://twitter.com/rob_neu">Rob</a> and <a href="http://twitter.com/ozzyr">Ozzy</a> on Twitter to catch them in their new antics.</p>
<h3>The history of WordPress, abridged edition</h3>
<p>Kinsta is a WordPress hosting company, and they spent some serious time putting together a <a href="https://kinsta.com/learn/wordpress-history/">pretty in-depth post</a> about the history of WordPress.</p>
<p>This is a good read, but it&#8217;s honestly (even with a post this size) really hard to capture the complete scope of WordPress and its history. There&#8217;s a good book on the way that will really tell the story, but for now, Kinsta&#8217;s post is quite the achievement, and you should definitely <a href="https://kinsta.com/learn/wordpress-history/">check it out</a>.</p>
<h3>iThemes Sync has an app for that</h3>
<p><span id="more-6863"></span></p>
<p>As <a href="http://chrislema.com/update-multiple-wordpress-sites/">Chris Lema highlights</a> with a video review, iThemes <a href="http://ithemes.com/2014/07/10/new-ithemes-sync-iphone-app/">has released an iOS app</a> for their Sync website management service.</p>
<p>Sync is looking really great, and might be worth checking out if you&#8217;re looking for new options in this changing space.</p>
<h3>The building blocks of responsive web design</h3>
<p>The Theme Foundry (a Post Status sponsor, for what it&#8217;s worth) did a nice <a title="RWD" href="https://thethemefoundry.com/blog/responsive-website-design/">write-up on the building blocks of responsive design</a>.</p>
<p>I especially liked this post because Drew focused on some things we forget some times, like scaling calls to action, line height, and font weights. There are also other good resources linked within.</p>
<h3>Design (more than just pixels) for your audience</h3>
<p>I read a lot of stuff that&#8217;s not strictly WordPress related. On Medium, Quartz strategist Mia Mabanta <a href="https://medium.com/@mia/getting-real-survey-answers-out-of-smart-busy-people-778f5a98e4c6">gives an in-depth look</a> at how the financial news website got excellent conversion numbers getting executive-level folks to fill out a survey.</p>
<p>The degree of strategic thinking and testing goes to show how well something can do if we put some real effort into it. This is a great case study that any consultant or product maker could learn from.</p>
<p>Another good read that&#8217;s not strictly WordPress is Brad Miller&#8217;s post on the <a href="http://liftux.com/posts/connection-customer-service-user-experience-design/">connection between customer service and user experience design</a>.</p>
<hr />
<p>&nbsp;</p>
<p>That&#8217;s it for the last week. Of course, these are all posts other folks have created. We also had a great week here at Post Status, including some guest posts from <a title="Automating i18n in WordPress themes" href="http://www.poststat.us/automating-i18n-wordpress-themes/">Brady Vercher</a> and <a title="Tips for local WordPress development with Varying Vagrant Vagrants (VVV)" href="http://www.poststat.us/vvv-tips-every-day/">Jason Resnick</a> I hope you&#8217;ll check out.</p>
<p>The days ahead are also shaping up nicely for Post Status. I hope you are all refreshed and ready as I am for a new week.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Jul 2014 00:28:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: A Proposed Enhancement That Saves A Mouse Click When Upgrading WordPress Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26203";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:224:"http://wptavern.com/a-proposed-enhancement-that-saves-a-mouse-click-when-upgrading-wordpress-plugins?utm_source=rss&utm_medium=rss&utm_campaign=a-proposed-enhancement-that-saves-a-mouse-click-when-upgrading-wordpress-plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1940:"<p>Four months ago, WordPress user <a title="https://profiles.wordpress.org/Fredelig" href="https://profiles.wordpress.org/Fredelig">Fredelig</a> <a title="https://core.trac.wordpress.org/ticket/27303" href="https://core.trac.wordpress.org/ticket/27303">created a new ticket</a> on WordPress trac suggesting the plugin update notification bubble load the page listing all of the plugins with pending upgrades.</p>
<p>In WordPress 3.9, clicking the notification loads Plugins.php which lists all of the activated plugins, including the ones with upgrades. This requires a second mouse click to show only the plugins that have an update available. Although it was too late to include in WordPress 3.9, it&#8217;s also missed the boat for 4.0.</p>
<div id="attachment_26260" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/MoreUsefulPluginUpgradeBubble.png" rel="prettyphoto[26203]"><img class="size-full wp-image-26260" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/MoreUsefulPluginUpgradeBubble.png?resize=621%2C131" alt="Better Plugin Upgrade Notification Bubbles" /></a><p class="wp-caption-text">Better Plugin Upgrade Notification Bubbles</p></div>
<p>On a related note, I&#8217;d like to propose an enhancement to the comment notification bubble. Clicking on the notification currently loads edit-comments.php which displays both approved and moderated comments. Ninety-nine percent of the time when I click on the notification link, it&#8217;s because I want to approve a comment pending moderation.</p>
<p>Although the task can be accomplished with the way it works now, sometimes the comment I need to approve is not on the first page and I have to click the Pending comments link. Having the notifications bubble load the pending comments first would save me a mouse click.</p>
<p><strong>Do you have any pros or cons regarding the suggested enhancements?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 12 Jul 2014 06:37:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: WPWeekly Episode 154 – All About The Customizer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=26192&preview_id=26192";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:154:"http://wptavern.com/wpweekly-episode-154-all-about-the-customizer?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-154-all-about-the-customizer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2656:"<p>On this episode of WordPress Weekly, we give you the low down on all the new features in WordPress 4.0 beta 1. Later in the show, <a href="http://wp.mattwie.be/" title="http://wp.mattwie.be/">Matt Wiebe</a> who works for Automattic as a design engineer, joins us to discuss his thoughts on the WordPress customizer. Most of what we talked about stems from his <a href="http://wp.mattwie.be/2014/06/27/evolving-the-customizer/" title="http://wp.mattwie.be/2014/06/27/evolving-the-customizer/">recent blog post</a> highlighting some of the roadblocks the customizer has in its current state. Near the end of the show, we have a candid conversation on how the feature may evolve in the next 2-3 years. After the interview, I&#8217;m more optimistic of what the future holds for the customizer.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/preview-wordpress-4-0-features-beta-1-now-available-for-testing" title="http://wptavern.com/preview-wordpress-4-0-features-beta-1-now-available-for-testing">Preview WordPress 4.0 Features, Beta 1 Now Available for Testing</a><br />
<a href="http://wptavern.com/wordpress-tv-adds-its-first-german-presentation-konstantin-obenland-on-underscores" title="http://wptavern.com/wordpress-tv-adds-its-first-german-presentation-konstantin-obenland-on-underscores">WordPress.tv Adds Its First German Presentation: Konstantin Obenland on Underscores</a><br />
<a href="http://wptavern.com/wordpress-feature-plugin-planned-to-improve-image-editing-experience" title="http://wptavern.com/wordpress-feature-plugin-planned-to-improve-image-editing-experience">WordPress Feature Plugin Planned to Improve Image Editing Experience</a><br />
<a href="http://wptavern.com/wpbeginner-turns-5-celebrates-with-campaign-to-build-two-new-schools-in-guatemala" title="http://wptavern.com/wpbeginner-turns-5-celebrates-with-campaign-to-build-two-new-schools-in-guatemala">WPBeginner Turns 5, Celebrates With Campaign To Build Two New Schools In Guatemala</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, July 18th 3 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #154:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 12 Jul 2014 02:34:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"WPTavern: Gust Plugin Adds Support for Categories, Featured Images and Custom Post Types";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26217";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:218:"http://wptavern.com/gust-plugin-adds-support-for-categories-featured-images-and-custom-post-types?utm_source=rss&utm_medium=rss&utm_campaign=gust-plugin-adds-support-for-categories-featured-images-and-custom-post-types";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3760:"<p>The <a href="http://wordpress.org/plugins/gust/" target="_blank">Gust</a> plugin aims to provide a <a href="https://ghost.org/" target="_blank">Ghost</a>-style publishing experience within the WordPress admin. It was released at the end of last year by developer Arūnas Liuiza. He was disappointed that Ghost didn&#8217;t end up being a fork of WordPress, so he decided to package its best publishing features into a plugin. Gust adds a Ghost-style editor with a live preview pane to WordPress and includes support for Markdown.</p>
<p>Liuiza has been gradually improving the plugin and the 0.4.0 release is a total rewrite with several new features since the last time we <a href="http://wptavern.com/gust-plugin-brings-the-ghost-admin-panel-into-wordpress" target="_blank">featured</a> it on the Tavern. It&#8217;s now PHP 5.2 compatible. In addition to media upload capabilities, Gust now supports adding and assigning a featured image.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-featured-image.jpg" rel="prettyphoto[26217]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-featured-image.jpg?resize=1025%2C585" alt="edit-featured-image" class="aligncenter size-full wp-image-26224" /></a></p>
<p>The latest version includes the ability to create and add categories in addition to tags.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/category-support.jpg" rel="prettyphoto[26217]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/category-support.jpg?resize=1004%2C643" alt="category-support" class="aligncenter size-full wp-image-26218" /></a></p>
<p>Gust 0.4.0 adds autosave support so you don&#8217;t have to worry about saving your drafts as you are composing. This release includes support for custom fields (post meta) and adds experimental support for custom post types. You can enable that feature via the plugin&#8217;s settings page.</p>
<p>In the past, the Gust dashboard was difficult to find unless you knew how to navigate there. The latest release improves the discoverability of the Gust dashboard by adding tighter integration with the WordPress admin bar and post edit links.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/gust-dashboard.jpg" rel="prettyphoto[26217]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/gust-dashboard.jpg?resize=640%2C168" alt="gust-dashboard" class="aligncenter size-full wp-image-26219" /></a></p>
<p>You can easily edit any of your content in the Gust dashboard by clicking on the new link in the hover menu below posts/pages/CPTs.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-posts.jpg" rel="prettyphoto[26217]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-posts.jpg?resize=833%2C276" alt="edit-posts" class="aligncenter size-full wp-image-26221" /></a></p>
<p>Gust is by no means a perfect of full-featured editing experience, but it is a solid option for adding Markdown support with a live preview. Not every user likes the same flavor of WordPress and Gust adds an interesting alternative to the current publishing experience. In the future, we may see many more variations of the WordPress editor as the platform adds better support for interfacing with external apps.</p>
<p>If you like where the plugin is headed and want to help contribute, you can find Gust on <a href="https://github.com/ideag/gust" target="_blank">GitHub</a>. So far, it has received excellent ratings on WordPress.org and Liuiza has been adding regular improvements. You can download <a href="http://wordpress.org/plugins/gust/" target="_blank">Gust</a> for free via the plugin installer in the WordPress admin.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 12 Jul 2014 00:09:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: THBusiness: A Free WordPress Business Theme Based on Bootstrap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26181";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:186:"http://wptavern.com/thbusiness-a-free-wordpress-business-theme-based-on-bootstrap?utm_source=rss&utm_medium=rss&utm_campaign=thbusiness-a-free-wordpress-business-theme-based-on-bootstrap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3206:"<p>If you&#8217;re looking for a clean, customizable business theme for WordPress, <a href="http://wordpress.org/themes/thbusiness" target="_blank">THBusiness</a> just landed in the official Themes Directory. While most free themes are dedicated to blogging, THBusiness is focused on providing all of the basic elements you need to display featured content, services, testimonials, and more.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/THbusiness.png" rel="prettyphoto[26181]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/THbusiness.png?resize=880%2C660" alt="THbusiness" class="aligncenter size-full wp-image-26186" /></a></p>
<p>It was designed by the folks at <a href="http://www.themezhut.com/" target="_blank">THEMEZHUT</a> to have a big visual impact on the homepage. The theme is based on <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a> and includes a full width Flexslider, which can be easily configured in the options panel.</p>
<p>Most of the layout is managed by widgets. THBusiness includes a total of eight different widget areas, with four of them located on the homepage.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/widgets.jpg" rel="prettyphoto[26181]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/widgets.jpg?resize=944%2C256" alt="widgets" class="aligncenter size-full wp-image-26183" /></a></p>
<p>It also includes six business-specific widgets that make it easy to set up featured images, services, testimonials, a call to action, and recent work. THBusiness has support for <a href="http://fortawesome.github.io/Font-Awesome/" target="_blank">Font Awesome</a> icons and adding them to the widgets doesn&#8217;t require adding any extra markup.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/recent-work-testimonials.jpg" rel="prettyphoto[26181]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/recent-work-testimonials.jpg?resize=805%2C784" alt="recent-work-testimonials" class="aligncenter size-full wp-image-26198" /></a></p>
<p>The options panel lets you easily add a custom logo, favicon, and footer description. Check out a <a href="http://www.themezhut.com/demo/thbusiness/" target="_blank">live demo of THBusiness</a> to see it in action.</p>
<p>Using THBusiness means that you can take advantage of any of the Bootstrap components such as labels, alerts, thumbnails, buttons, badges and more. While not everyone is a fan of reusable UI components, they can help to keep a website&#8217;s look consistent. If you&#8217;re not a designer, working with a frontend framework like <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a> makes it easy to mix in different UI elements without having to reinvent the wheel.</p>
<p><a href="http://wordpress.org/themes/thbusiness" target="_blank">THBusiness</a> is a clean business theme that doesn&#8217;t pack in a lot of complicated options. It&#8217;s easy to setup by dropping widgets into the homepage widget areas and you can have your site looking like the demo in a matter of minutes. Download it for free through your WordPress admin theme browser.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Jul 2014 18:13:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"Post Status: Tips for local WordPress development with Varying Vagrant Vagrants (VVV)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=6848";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://www.poststat.us/vvv-tips-every-day/?utm_source=rss&utm_medium=rss&utm_campaign=vvv-tips-every-day";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6721:"<p><img class="aligncenter size-large wp-image-6861" src="http://www.poststat.us/wp-content/uploads/2014/07/vvv-tips-752x300.jpg" alt="vvv-tips" width="752" height="300" />I’ve used local development environments for as long as I can remember.  They’ve always been a fluid part of being a developer.  The biggest pain point was keeping everything upgraded at all times and switching from one stack to another.</p>
<p>In case you didn’t notice, I said ”was”.  This is because in the Spring of 2013 I found Varying Vagrant Vagrants, or <a href="https://github.com/Varying-Vagrant-Vagrants/VVV">VVV</a>.  With VVV you can have your local WordPress development environment virtually silo’d in it’s own container.</p>
<p>There are many tutorials out there explaining the <a href="http://chriswiegman.com/2013/08/virtual-machines-the-holy-grail-of-local-web-development/">what and why you should use a virtualized development environment</a>, <a href="https://docs.vagrantup.com/v2/getting-started/">how to setup Vagrant</a>, and <a href="http://wptavern.com/wordpress-theme-review-vvv-a-quick-vagrant-setup-for-testing-and-reviewing-themes">how to setup VVV</a> so I won’t dive deep there.</p>
<p>My take away is just that I want to be able to have an environment that’s flexible, quick, and not so dependent upon the hardware and software installed on my computer.</p>
<p>With that, here are my most used tips for everyday usage of VVV.  I do mention some of the initial pain points I had with VVV, but with some digging around I found solutions that I would like to share with you.</p>
<h3>1. Creating a new site</h3>
<p>TL;DR <code>vvv new mysite.dev -v 3.9.1</code></p>
<p>I’m not a systems engineer by any means.  I know enough to be helpful, but not enough to build a full stack.  So when I jumped into VVV for the first time, I had an issue with trying to get my existing sites into the /www root directory.</p>
<p>The way I work is that I have a /Sites directory, then under that is each website that I am working on.  When I installed VVV for the first time, I installed it in that /Sites folder only to realize that I probably should’ve installed it outside of that.</p>
<p>But that was an easy fix.  <code>vagrant destroy</code> and start again where I wanted.</p>
<p>Once I created a site or two I realized that I wanted to automate this process a bit more than the <a href="https://github.com/Varying-Vagrant-Vagrants/VVV/wiki/Auto-site-Setup">Auto site Setup</a> that VVV has built in.  After a quick search I found <a href="https://github.com/aliso/vvv-site-wizard">VVV Site Wizard</a>.</p>
<p>This great script allowed me to create a new site with any version of WP I wanted simply by typing <code>vvv new mysite.dev -v 3.9.1</code> where the -v grabs the version of WordPress I want and installs it.  If left off, then it’ll grab the latest.</p>
<p>I didn’t have to mess with database or nginx files, or provision scripts either.  After typing in that simple command, I had a brand new site installed and ready to go in seconds.</p>
<h3>2. Connecting to MySQL</h3>
<p>At first glance, I was unsure on using MySQL as I had in the past since I didn’t like using phpMyAdmin for database work.  I like to use Sequel Pro (on OS X) to run queries and look at the data.</p>
<p>I wasn’t sure how I was going to connect to MySQL since normally I would just put in my connection string with the host information and it would connect.  With VVV I wouldn’t be able to put in localhost and the user credentials and have it connect, since technically my sites were no longer on my localhost.</p>
<p>The way to do it is via <a href="https://github.com/Varying-Vagrant-Vagrants/VVV/wiki/Connecting-to-MySQL#ssh-tunnel">SSH Tunnel</a>.  In layman&#8217;s terms, that’s just relaying the information via SSH.</p>
<p>So whether you are using Sequel Pro or some other MySQL application, look for SSH Tunnel when setting up your connection.</p>
<p>Here&#8217;s what mine looks like:</p>
<div id="attachment_6852" class="wp-caption aligncenter"><img class="wp-image-6852 size-full" src="http://www.poststat.us/wp-content/uploads/2014/07/sequel-pro-vvv.png" alt="sequel-pro-vvv" width="454" height="470" /><p class="wp-caption-text">Yes I know it&#8217;s bad practice to have root user, but if you have my laptop, then it doesn&#8217;t matter what the password is.</p></div>
<h3>3. Restarting Services</h3>
<p>This isn’t something that I do all that often, but there are times that I will need to do this often enough that I wanted to share it.</p>
<p>Sometimes when I run <code>vagrant up</code> MySQL doesn’t start and I’ll get the WordPress “Error Establishing a Database Connection”.</p>
<p>With two commands, this is easily fixed.  First type <code>vagrant ssh</code> and then type <code>sudo service mysql start</code>.  After a few seconds, you should be good to go.</p>
<p>One of the great features of VVV is that unless you destroy your setup, any changes you make within the instance will persist.  So there are times when I have to setup custom nginx directives and restart the service.</p>
<p><code>sudo service nginx restart</code> does the trick.</p>
<h4>Clean slate</h4>
<p>After a long day of WordPress development, it’s great to just type <code>vagrant halt</code>, watch my resources come back available, and know that my laptop is free of any development environment burden.</p>
<p>Since 2013 when I really went neck deep into virtualizing my development environment, I can’t tell you how awesome it is to see the WordPress community embracing this as well.  This only serves us as developers more ability to push forward with the latest and greatest plugins, themes, and core as the architectures we work on mature.</p>
<div id="single-hcard-jasonresnick" class="loop-meta vcard"><h4 class="author-bio fn n">Jason Resnick</h4><div class="author-description"><img alt="Jason Resnick" src="http://0.gravatar.com/avatar/022e1ac79e7186ee6ef38c3916388aa0?s=150&d=http%3A%2F%2F0.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D150&r=G" class="avatar avatar-150 photo" height="150" width="150" /><div class="user-bio author-bio">Jason Resnick is a WordPress developer, founder of <a href="http://rezzz.com">rezzz.com</a> &amp; <a href="http://www.rezzz.com/wp-field-guides">WP Field Guides</a> and is a co-host of the WordPress development podcast <a href="http://wpdevtable.com">WP Dev Table</a>. Jason is a sports nut, even if all the teams he follows seem to lose.  Follow Jason on Twitter <a href="https://twitter.com/rezzz">@rezzz</a></div><!-- .user-bio .author-bio --></div><!-- .loop-description --></div><!-- .loop-meta -->";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Jul 2014 17:45:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jason Resnick";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: Nantes, France to Host a WordCamp for Developers in November";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26144";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/nantes-france-to-host-a-wordcamp-for-developers-in-november?utm_source=rss&utm_medium=rss&utm_campaign=nantes-france-to-host-a-wordcamp-for-developers-in-november";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3339:"<div id="attachment_26166" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/nantes.jpg" rel="prettyphoto[26144]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/nantes.jpg?resize=1025%2C681" alt="Nantes" class="size-full wp-image-26166" /></a><p class="wp-caption-text">Nantes</p></div>
<p>France is getting its second official WordCamp. The event is called <a href="http://2014.wptech.fr/" target="_blank">WordCamp Nantes WP Tech</a> and will be held in Nantes on Saturday, November 29, 2014. Unlike your traditional WordCamp, WP Tech will be devoted entirely to developers.</p>
<p><strong>&#8220;The idea is to share knowledge, ideas and best practices about WordPress development,&#8221;</strong> organizer Daniel Roch told the Tavern. &#8220;It&#8217;s slightly different from a basic WordCamp because there will only be one track about development.&#8221;</p>
<p>Roch is joined by four others on the organization team and they are expecting 100-300 attendees at <a href="http://www.epitech.eu/" target="_blank">Epitech</a>, a school for computer innovation. &#8220;All of us thought that there weren&#8217;t enough technical conferences about WordPress. In fact, we spoke with many developers, and all of them were enjoying the idea of a WordCamp Developer Edition.&#8221;</p>
<div id="attachment_26151" class="wp-caption alignright"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/venue-nantes.jpg" rel="prettyphoto[26144]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/venue-nantes.jpg?resize=300%2C225" alt="La salle de l’Epitech Nantes" class="size-medium wp-image-26151" /></a><p class="wp-caption-text">La salle de l’Epitech Nantes</p></div>
<p>The selected venue is located in the center of downtown Nantes, as the event was born out of <a href="http://www.wp-nantes.org/" target="_blank">WP Nantes</a>, a thriving local meetup group. The organizers are looking for passionate speakers to present on technical topics. &#8220;It doesn&#8217;t matter if you&#8217;re an expert about your topic,&#8221; Roch said. &#8220;You must be passionate! Concerning the topics, we&#8217;re looking for presentations on coding best practices, security, performance, APIs, etc.&#8221;</p>
<p>WP Tech organizers are considering adding a contributor day, but Roch said they don&#8217;t wish to stretch themselves too thin for the first event. &#8220;It would be great for us to have a contributor day, but we are afraid to bite off more than we can chew. We think it&#8217;s better to have a smaller yet well organized event, rather than a disappointing one.&#8221; They remain undecided about adding a contributor day.</p>
<p>The call for speakers is already open and those selected will be paid for travel and hotel. Presentations will be given in both English and French. Applications to speak will be closed Tuesday, July 15, at midnight.  <a href="http://2014.wptech.fr/appel-orateurs/" target="_blank">Contact the organizers</a> if you wish to participate. Developers, designers and project managers are all encouraged to attend WP Tech to learn more about mastering WordPress. Sign up on the event&#8217;s <a href="http://2014.nantes.wordcamp.org/" target="_blank">WordCamp site</a> (coming soon) to be notified of updates.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 21:37:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: Blue Steel: A Free WordPress Theme Based on Roots";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26074";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:160:"http://wptavern.com/blue-steel-a-free-wordpress-theme-based-on-roots?utm_source=rss&utm_medium=rss&utm_campaign=blue-steel-a-free-wordpress-theme-based-on-roots";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3325:"<p><a href="http://roots.io/" target="_blank">Roots</a> is a WordPress starter theme that makes use of HTML5 Boilerplate, Bootstrap, and Grunt. Over the years Roots has garnered somewhat of a cult following and is still going strong with the release of <a href="http://roots.io/roots-7-0-0-updates/" target="_blank">version 7.0.0</a> last week. This release moves some of the theme&#8217;s trademark features into a plugin called <a href="http://wptavern.com/soil-roots-framework-features-that-can-be-used-with-any-wordpress-theme" target="_blank">Soil</a> and adds Bower for front-end package management.</p>
<p>Blue Steel is a new open source theme built to run on top of Roots. It was inspired by the design of <a href="http://www.theverge.com/" target="_blank">The Verge</a> and, of course, the film <a href="https://www.youtube.com/watch?v=D519hT7-ytY" target="_blank">Zoolander</a>. <a href="https://twitter.com/dhawalhshah" target="_blank">Dhawal Shah</a> introduced his new theme on the Roots discussion boards under a <a href="http://discourse.roots.io/t/new-roots-theme-blue-steel-mit-license/1905" target="_blank">thread</a> titled: <strong>&#8220;Is there more to a blog than being really really really ridiculously good looking?&#8221;</strong></p>
<p>Blue Steel is the answer to that question. It was originally created for use on <a href="https://www.class-central.com/" target="_blank">Class Central</a>, a website dedicated to helping people discover free online classes (MOOCs) from top universities such as Stanford, MIT, and Harvard.</p>
<p>The theme is responsive and resizes down nicely to use mobile-friendly navigation. The <a href="https://www.class-central.com/report/" target="_blank">homepage</a> sports a flat, minimalist style with bold colors and features your latest content with room for a sidebar.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/homepage.jpg" rel="prettyphoto[26074]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/homepage.jpg?resize=764%2C626" alt="homepage" class="aligncenter size-full wp-image-26135" /></a></p>
<p>Blue Steel <a href="https://www.class-central.com/report/udacity-kunal-chawla/" target="_blank">blog posts</a> are styled with readable typography and attractive pullquotes.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/blue-steel-blog-posts.jpg" rel="prettyphoto[26074]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/blue-steel-blog-posts.jpg?resize=1025%2C698" alt="blue-steel-blog-posts" class="aligncenter size-full wp-image-26131" /></a></p>
<p>This is not exactly your average plug-and-play style WordPress theme. In order to use it you must be familiar with both <a href="http://roots.io/" target="_blank">Roots</a> and <a href="https://getcomposer.org/" target="_blank">Composer</a>. You will also be required to modify it to suit your own needs, but it does provide an excellent starting place for creating your own Roots-powered theme.</p>
<p>Blue Steel is released under a GPL-compatible MIT license. Many thanks to the folks at <a href="http://codelight.eu/" target="_blank">Codelight</a> who decided to make it available on <a href="https://github.com/classcentral/blue-steel" target="_blank">GitHub</a> so anyone can fork it for an easy start.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 20:09:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"WPTavern: WordPress Mini Conference “East Meets Press” Set For September 17-21, 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26058";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:206:"http://wptavern.com/wordpress-mini-conference-east-meets-press-set-for-september-17-21-2014?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-mini-conference-east-meets-press-set-for-september-17-21-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2444:"<p><a title="http://eastmeetspress.com/" href="http://eastmeetspress.com/">East Meets Press</a> is a business focused WordPress event organized by Ben Fox that will be held on <strong>September 17-21</strong> (Wednesday to Sunday – 4 nights). Not to be outdone by BeachPress which was recently held on the West Coast of the US, East Meets Press will take place on the East Coast in Kure Beach, North Carolina.</p>
<div id="attachment_26110" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/EastMeetsPressVenue.jpg" rel="prettyphoto[26058]"><img class="size-full wp-image-26110" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/EastMeetsPressVenue.jpg?resize=550%2C365" alt="The Venue For East Meets Press" /></a><p class="wp-caption-text">The Venue For East Meets Press</p></div>
<p>Individual tickets are <strong>$600.</strong> The tickets are all-inclusive so they cover lodging, internet, food, and beverages. Companies that can&#8217;t attend but want to support the event can do so with the <strong>$400</strong> sponsor ticket.</p>
<p>Without the hustle and bustle of attending sessions and having limited networking time at a WordCamp, this event gives attendees a chance to get to know each another while discussing the business of WordPress in a relaxing atmosphere. There will be set meal times with a given topic of discussion as well as one 15 minute lightning talk each day. Outside of that, attendees will be free to do whatever they want.</p>
<p>It&#8217;s nice to see these type of events unfold within the WordPress community. They&#8217;re like miniature versions of <a title="http://wptavern.com/dates-announced-for-pressnomics-3-jan-22nd-24th-2015" href="http://wptavern.com/dates-announced-for-pressnomics-3-jan-22nd-24th-2015">PressNomics</a>. If you plan on going, let us know in the comments and be sure to <a title="http://eastmeetspress.com/?espresso_events=east-coast-press-2014" href="http://eastmeetspress.com/?espresso_events=east-coast-press-2014">register your tickets</a> as space is limited.</p>
<p>If you attended <a title="http://zao.is/2013/10/beachpress-2-0/" href="http://zao.is/2013/10/beachpress-2-0/">BeachPress 2014</a> or <a title="http://bigsnowtinyconf.com/" href="http://bigsnowtinyconf.com/">Big Snow Tiny Conference 2014,</a> I&#8217;d love to hear about your experience in the comments, especially if it improved your business.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 18:40:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Akismet: Akismet 3.0.1 for WordPress Now Available";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1615";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://blog.akismet.com/2014/07/10/akismet-3-0-1-for-wordpress-now-available/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1574:"<p>Extry, extry, read all about it! Version 3.0.1 of <a href="http://wordpress.org/plugins/akismet/">the Akismet plugin for WordPress</a> is now available!</p>
<p>Even though it&#8217;s not a big round number like our 3.0 release, we&#8217;ve worked hard to make Akismet even better in 3.0.1:</p>
<ul>
<li>We&#8217;ve reduced the amount of data we store in the <code>akismet_as_submitted</code> comment meta value for each comment.</li>
<li>Akismet no longer depends on the <code>fsockopen</code> PHP function.</li>
<li>jQuery is no longer required for Akismet&#8217;s frontend JavaScript.</li>
<li>We fixed a bug that was causing spam reports from outside of the dashboard (the iOS app, for example) to be ignored.</li>
<li>If an API key is suspended for any reason, comments will now all be sent to the Pending queue instead of the Spam folder.</li>
<li>&#8230;and lots of other improvements to performance and error-handling.</li>
</ul>
<p>To upgrade, visit the Plugins or Updates page of your WordPress dashboard and follow the instructions. If you need to download the zip file directly, links to all versions are available in <a href="http://wordpress.org/plugins/akismet/">the WordPress plugins directory</a>.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1615/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1615/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1615&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 17:45:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Christopher Finke";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Matt: 4 Years Working Remotely";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43867";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://ma.tt/2014/07/4-years-working-remotely/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:245:"<p>Sara Rosso writes <a href="http://whenihavetime.com/2014/07/08/10-lessons-from-4-years-working-remotely/">10 Lessons from 4 Years Working Remotely at Automattic</a>. (Lesson 11, left out: Always give list articles an odd number of items.)</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 16:13:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: Preview WordPress 4.0 Features, Beta 1 Now Available for Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26019";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:190:"http://wptavern.com/preview-wordpress-4-0-features-beta-1-now-available-for-testing?utm_source=rss&utm_medium=rss&utm_campaign=preview-wordpress-4-0-features-beta-1-now-available-for-testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4630:"<p><a href="http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/" target="_blank">WordPress 4.0 Beta 1</a> is now available for download and testing. This means that core developers are now onto the stage of bug fixes and inline documentation in preparation for the official release in <a href="http://make.wordpress.org/core/version-4-0-project-schedule/" target="_blank">August</a>.</p>
<p>Helen Hou-Sandí, the release lead, announced the beta with an outline of user-facing features that need testing. The list offers a good summary of some of the exciting changes and improvements coming in WordPress 4.0:</p>
<ul>
<li>Previews of oEmbed URLs in the visual editor and via the &#8220;Insert from URL&#8221; tab in the media modal.</li>
<li>Media library &#8220;grid view&#8221; added in addition to the &#8220;list view&#8221;</li>
<li>Refreshed plugin <a href="https://core.trac.wordpress.org/ticket/27440" target="_blank">install</a> and <a href="https://core.trac.wordpress.org/ticket/28785" target="_blank">search</a> experience</li>
<li>Select a language when installing WordPress</li>
<li>Improvements to editor resizing its top and bottom bars pin when needed</li>
<li>Improvements to keyboard and cursor interaction with <a href="https://core.trac.wordpress.org/ticket/28595" target="_blank">TinyMCE views</a></li>
<li>Widgets in the Customizer are now loaded in a separate panel</li>
<li>Improvements to formatting functions</li>
</ul>
<p>When testing the beta, you&#8217;ll find that the grid view for the media library is on by default. You have the option to toggle back to the list view, but I&#8217;m not sure why you ever would. The new grid view is truly a thing of beauty and has evolved considerably since last October when we <a href="http://wptavern.com/new-grid-view-coming-to-the-wordpress-media-library" target="_blank">featured</a> it during its initial development.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/grid-view.jpg" rel="prettyphoto[26019]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/grid-view.jpg?resize=966%2C582" alt="grid-view" class="aligncenter size-full wp-image-26087" /></a></p>
<p>The bulk edit option allows you to quickly delete multiple images. Clicking on individual items launches a details modal where you can edit an attachment and even navigate between items directly in the modal.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/details-modal.jpg" rel="prettyphoto[26019]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/details-modal.jpg?resize=718%2C542" alt="details-modal" class="aligncenter size-full wp-image-26089" /></a></p>
<p>There are a lot of changes packed into WordPress media in the upcoming release and any help testing would be beneficial to the core team.</p>
<p>The plugin search and installation process is another highly visible feature with a fresh new look. Check out the new <a href="http://wptavern.com/first-look-at-the-new-plugin-details-screen-coming-to-wordpress-4-0" target="_blank">plugin details modal</a> as well as the new grid view when searching for an extension.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/search-plugins.jpg" rel="prettyphoto[26019]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/search-plugins.jpg?resize=951%2C338" alt="search-plugins" class="aligncenter size-full wp-image-26091" /></a></p>
<p>You can help by testing the plugin modals and cards on as many screens and accessibility devices as possible in order to hunt down any bugs with the new display.</p>
<p>As this is a major release of WordPress, developers would do well to test their sites, themes and plugins against the beta while it&#8217;s still early. Hou-Sandí encourages anyone who has found a bug to post in the <a href="http://wordpress.org/support/forum/alphabeta" target="_blank">Alpha/Beta forum</a> or <a href="https://make.wordpress.org/core/reports/" target="_blank">file a ticket on trac</a>. The <a href="http://core.trac.wordpress.org/tickets/major" target="_blank">list of known bugs</a> will show you what testers have already identified so far. Some of those bugs may have already been <a href="http://core.trac.wordpress.org/query?status=closed&group=component&milestone=4.0" target="_blank">fixed</a>. Your bug reports and patches will help to make WordPress 4.0 shiny and polished when it&#8217;s officially released in August. Download Beta 1 from the <a href="http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/" target="_blank">release announcement</a> on WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 16:07:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Dev Blog: WordPress 4.0 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3248";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4016:"<p>WordPress 4.0 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta1.zip">download the beta here</a> (zip).</p>
<p>4.0 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Previews of <a href="http://codex.wordpress.org/Embeds">embedding via URLs</a></strong> in the visual editor and the &#8220;Insert from URL&#8221; tab in the media modal. Try pasting a URL (such as a <a href="http://wordpress.tv/">WordPress.tv</a> or YouTube video) onto its own line in the visual editor. (<a href="https://core.trac.wordpress.org/ticket/28195">#28195</a>, <a href="https://core.trac.wordpress.org/ticket/15490">#15490</a>)</li>
<li>The <strong>Media Library</strong> now has a &#8220;grid&#8221; view in addition to the existing list view. Clicking on an item takes you into a modal where you can see a larger preview and edit information about that attachment, and you can navigate between items right from the modal without closing it. (<a href="https://core.trac.wordpress.org/ticket/24716">#24716</a>)</li>
<li>We&#8217;re freshening up the <strong>plugin install experience</strong>. You&#8217;ll see some early visual changes as well as more information when searching for plugins and viewing details. (<a href="https://core.trac.wordpress.org/ticket/28785">#28785</a>, <a href="https://core.trac.wordpress.org/ticket/27440">#27440</a>)</li>
<li><strong>Selecting a language</strong> when you run the installation process. (<a href="https://core.trac.wordpress.org/ticket/28577">#28577</a>)</li>
<li>The <strong>editor</strong> intelligently resizes and its top and bottom bars pin when needed. Browsers don&#8217;t like to agree on where to put things like cursors, so if you find a bug here, please also let us know your browser and operating system. (<a href="https://core.trac.wordpress.org/ticket/28328">#28328</a>)</li>
<li>We&#8217;ve made some improvements to how your keyboard and cursor interact with <strong>TinyMCE views</strong> such as the gallery preview. Much like the editor resizing and scrolling improvements, knowing about your setup is particularly important for bug reports here. (<a href="https://core.trac.wordpress.org/ticket/28595">#28595</a>)</li>
<li><strong>Widgets in the Customizer</strong> are now loaded in a separate panel. (<a href="https://core.trac.wordpress.org/ticket/27406">#27406</a>)</li>
<li>We&#8217;ve also made some changes to some <strong>formatting</strong> functions, so if you see quotes curling in the wrong direction, please file a bug report.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&group=component&milestone=4.0">everything we’ve fixed</a> so far.</p>
<p><strong>Developers:</strong> Never fear, we haven&#8217;t forgotten you. There&#8217;s plenty for you, too &#8211; more on that in upcoming posts. In the meantime, check out the <a href="http://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/#customizer-panels">API for panels in the Customizer</a>.</p>
<p>Happy testing!</p>
<p><em>Plugins, editor</em><br />
<em>Media, things in between</em><br />
<em>Please help look for bugs</em></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 10:17:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: WP Engine Becomes The First Large Partner To Integrate Sidekick";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26052";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:190:"http://wptavern.com/wp-engine-becomes-the-first-large-partner-to-integrate-sidekick?utm_source=rss&utm_medium=rss&utm_campaign=wp-engine-becomes-the-first-large-partner-to-integrate-sidekick";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2152:"<div id="attachment_26073" class="wp-caption alignright"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/WP-Engine-SIDEKICK-Portal.png" rel="prettyphoto[26052]"><img class="wp-image-26073 size-full" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/WP-Engine-SIDEKICK-Portal.png?resize=296%2C457" alt="WP Engine User Portal" /></a><p class="wp-caption-text">WP Engine User Portal</p></div>
<p>WP Engine has <a title="http://wpengine.com/blog/#/2014/07/09/introducing-interactive-tutorials-within-user-portal/" href="http://wpengine.com/blog/#/2014/07/09/introducing-interactive-tutorials-within-user-portal/">revamped their user portal</a> and is the first large partner to integrate <a title="http://www.sidekick.pro/" href="http://www.sidekick.pro/">Sidekick</a> into its service. Sidekick provides WP Engine customers access to guided tours for understanding how different components of the User Portal work together. Sidekick is a product created by FlowPress to create interactive, narrated, guided walkthroughs. The new user portal has guides to learn about the WP Engine platform, managing your account, setting up your site, etc.</p>
<p>I was granted access to a WP Engine staging server to experience the benefits these guides offer and I&#8217;m impressed. They&#8217;re a helping hand at the click of a button. The walkthroughs are clear and to the point. Unlike reading tutorials or watching videos, it was nice to be guided through the process of managing my account.</p>
<p>The magic behind the walkthroughs is <a title="http://www.sidekick.pro/composer/" href="http://www.sidekick.pro/composer/">Sidekick Composer</a>. Although not available to the public yet, I consider it the Camtasia studio for WordPress. After watching a demo of what this plugin is capable of, I think plugin authors are going to love it. Instead of using pointers, they&#8217;ll be able to create interactive tours with narrated explanations on how to configure or use their plugin.</p>
<p>Keep an eye on the Tavern as rumor has it, the beta period for Sidekick Composer will open soon. When it happens, we&#8217;ll let you know.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 05:36:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: Create Your Own Custom Pointers in the WordPress Admin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26025";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:172:"http://wptavern.com/create-your-own-custom-pointers-in-the-wordpress-admin?utm_source=rss&utm_medium=rss&utm_campaign=create-your-own-custom-pointers-in-the-wordpress-admin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4358:"<p>Admin pointers were first added in <a href="http://codex.wordpress.org/Version_3.3" target="_blank">WordPress 3.3</a> for the purpose of helping users discover and navigate new features in major releases. For example, when widgets were added to the customizer, an admin pointer displayed to highlight live widget previews on the themes page.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/new-feature-admin-pointer.jpg" rel="prettyphoto[26025]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/new-feature-admin-pointer.jpg?resize=743%2C495" alt="new-feature-admin-pointer" class="aligncenter size-full wp-image-26034" /></a></p>
<p>The friendly pointers, when used sparingly, can draw attention to important items and help new users more effectively navigate the admin. Ordinarily, creating your own pointers requires a bit of custom coding. Fortunately, the admin pointers feature is easy to extend, so plugin developers have been able to harness it for unique uses.</p>
<p><a href="http://wordpress.org/plugins/better-admin-pointers/" target="_blank">Better Admin Pointers</a> is a plugin that makes it possible for anyone to create custom pointers and add them to any screen in the admin. The plugin saves the new pointers as a custom post type. Pointers will display until they are dismissed by the user.</p>
<p>Here&#8217;s an example of a pointer created to identify which plugin you&#8217;re editing:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-plugin.png" rel="prettyphoto[26025]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-plugin.png?resize=1025%2C681" alt="edit-plugin" class="aligncenter size-full wp-image-26045" /></a></p>
<h3>Pointer Customization Options</h3>
<p>Better Admin Pointers allows you to customize every aspect of your custom pointers, including:</p>
<ul>
<li>Main content area</li>
<li>Pointer id &#8211; A unique id so that it can be tracked in the WP DB as dismissed</li>
<li>Screen &#8211; What page/screen it should appear on</li>
<li>Target &#8211; CSS id or class we want the pointer to attach to on the screen above</li>
<li>Position Edge &#8211; Which edge should be adjacent to the target? (left, right, top, or bottom)</li>
<li>Position Align &#8211; How should the pointer be aligned on this edge, relative to the target? (top, bottom, left, right, or middle)</li>
</ul>
<p>The plugin&#8217;s settings page has a checkbox option to &#8220;show current screen,&#8221; which will display the value you need for the screen ID when creating a new pointer.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/screen-id.jpg" rel="prettyphoto[26025]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/screen-id.jpg?resize=656%2C361" alt="screen-id" class="aligncenter size-full wp-image-26048" /></a></p>
<p>The WordPress Plugin API also has a handy <a href="http://codex.wordpress.org/Plugin_API/Admin_Screen_Reference" target="_blank">Admin Screen Reference</a> where you can easily locate IDs for the screens.</p>
<p><strong>A point of caution here:</strong> It&#8217;s easy to go overboard creating too many admin pointers. Some popular plugins annoy users to no end with their ever-present pointers. Don&#8217;t make this mistake if you decide to customize your own.</p>
<p>While testing the plugin, I was able to create and customize pointers faster than I imagined. The custom post type essentially guides you through the process with an explanation of the values expected in each box. For the average user, the most difficult aspect of customizing a pointer might be setting the target. If you&#8217;re not familiar with using your browser to inspect elements, it may be frustrating to determine the right CSS class or ID to use. However, the plugin&#8217;s most typical use case is most likely to be a developer setting up pointers for a client website or for someone who is new to WordPress.</p>
<p>I can see pointers being very useful for helping clients navigate custom features that a developer has built into the admin. <a href="http://wordpress.org/plugins/better-admin-pointers/" target="_blank">Better Admin Pointers</a> provides a quick way to write up a few friendly pointers to accompany new or confusing screens. Download it for free from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 23:03:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: First Look At The New Plugin Details Screen Coming To WordPress 4.0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26010";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:198:"http://wptavern.com/first-look-at-the-new-plugin-details-screen-coming-to-wordpress-4-0?utm_source=rss&utm_medium=rss&utm_campaign=first-look-at-the-new-plugin-details-screen-coming-to-wordpress-4-0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2472:"<p>In the past two weeks, a lot of work has been done to improve the various plugin installer modals in the backend of WordPress. A <a title="http://en.wikipedia.org/wiki/Modal_window" href="http://en.wikipedia.org/wiki/Modal_window">modal</a> is a fancy way of saying a dialog or popup box. One of the modals revamped is the <a title="https://core.trac.wordpress.org/ticket/27440" href="https://core.trac.wordpress.org/ticket/27440">plugin details view</a>. When users click on the details link when searching for plugins to install from the backend of WordPress, a dialog box appears showing detailed plugin information. Here is what the current implementation looks like.</p>
<div id="attachment_26039" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/WPPluginInstallModelBefore.png" rel="prettyphoto[26010]"><img class="size-full wp-image-26039" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/WPPluginInstallModelBefore.png?resize=866%2C878" alt="Current Plugin Details Modal View" /></a><p class="wp-caption-text">Current Plugin Details Modal View</p></div>
<p>Here&#8217;s what the new view looks like. Keep in mind that it&#8217;s a work in progress.</p>
<div id="attachment_26043" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/WPPluginInstallModelAfter.png" rel="prettyphoto[26010]"><img class="size-full wp-image-26043" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/WPPluginInstallModelAfter.png?resize=837%2C852" alt="The Detailed Modal View For WordPress 4.0" /></a><p class="wp-caption-text">The Detailed Modal View For WordPress 4.0</p></div>
<p>As you can see, the plugin&#8217;s banner image is displayed at the top. A reviews tab has been added making it easy to read the latest reviews. In addition to the average rating, you can now see how the average is determined. All contributors to the plugin are listed along with their Gravatars. When the modal view shrinks, the detailed information is displayed above the description text.</p>
<p>I found the reviews hard to read in chronological order because it&#8217;s difficult to determine where a review begins and ends. Showing Gravatars is neat but I question their usefulness if they are the size of favicons. Overall, I like the improvements and can&#8217;t wait to see what the finished product looks like.</p>
<p><strong>What do you think of the new look?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 22:19:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"Alex King: Custom Taxonomy as “Post Meta”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=14416";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://alexking.org/blog/2014/07/09/custom-taxonomy-as-post-meta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1135:"<p><em>I found this post while sorting through my old drafts and decided to go ahead and publish it rather than trashing it. Hopefully the code samples don&#8217;t break too badly in WordPress 3.9.</em></p>
<p>I&#8217;ve talked a bit about <a href="http://alexking.org/blog/2011/08/29/wordpress-post-meta-taxonomies">when to use custom taxonomies and when to use custom fields/post meta</a> (and how they can be used virtually interchangeably in some situations). If you want to use taxonomies, you&#8217;ll probably also want to:</p>
<ul>
<li>make sure that the terms you want to use exist in your custom taxonomy</li>
<li>limit the ability for these terms to be altered</li>
</ul>
<p>This Gist is a good start:</p>
<p><p>View the code on <a href="https://gist.github.com/3723819">Gist</a>.</p></p>
<p>You&#8217;ll probably also want to specify:</p>
<p><code>\'public\' =&gt; false,<br />
\'show_ui\' =&gt; true,</code></p>
<p>when defining your custom taxonomy. This makes the UI box for the taxonomy appear in the post/page editing interface as expected, but hides the admin forms for editing the taxonomy terms from the admin menu.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 21:33:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"Matt: Pitchforks for Plutocrats";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43859";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://ma.tt/2014/07/pitchforks-for-plutocrats/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:322:"<p>Nick Hanauer advocates for $15 minimum wage in <a href="http://www.politico.com/magazine/story/2014/06/the-pitchforks-are-coming-for-us-plutocrats-108014.html">The Pitchforks Are Coming&#8230; For Us Plutocrats</a>. He was the first non-family investor in Amazon.com, and as he puts it, a &#8220;zillionaire.&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 20:54:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: Kinsta Publishes Guide On The History Of WordPress, Its Ecosystem, and Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26008";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:220:"http://wptavern.com/kinsta-publishes-guide-on-the-history-of-wordpress-its-ecosystem-and-community?utm_source=rss&utm_medium=rss&utm_campaign=kinsta-publishes-guide-on-the-history-of-wordpress-its-ecosystem-and-community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1316:"<p>Mark Gavalda, CEO of <a title="https://kinsta.com/" href="https://kinsta.com/">Kinsta WordPress Hosting</a>, has <a title="https://kinsta.com/learn/wordpress-history/" href="https://kinsta.com/learn/wordpress-history/">published an in-depth guide</a> covering the history of WordPress, its vast ecosystem, and the community surrounding it. Gavalda does a great job explaining the impact WordPress has had on so many individuals and businesses with quotes from notable members of the community.</p>
<p>The largest take away for me is that despite taking over an hour to read, it only scratches the surface. One of my favorite parts is a quote from Matt Mullenweg on contributing to WordPress.</p>
<blockquote><p>Just remember, every contribution counts, no matter what it looks like. It takes every one of us to make WordPress better.</p></blockquote>
<p>If you&#8217;d like to know more about the history of the project before it became WordPress, check out <a title="https://hakre.wordpress.com/2011/01/25/milestones-of-wordpress-early-project-timeline-ca-2000-to-2005/" href="https://hakre.wordpress.com/2011/01/25/milestones-of-wordpress-early-project-timeline-ca-2000-to-2005/">this list of milestones by Hakre</a>. His post covers the events in the 2000-2005 timeline that include the birth of WordPress.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 20:07:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"WPTavern: WordPress.tv Adds Its First German Presentation: Konstantin Obenland on Underscores";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=25985";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:228:"http://wptavern.com/wordpress-tv-adds-its-first-german-presentation-konstantin-obenland-on-underscores?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-tv-adds-its-first-german-presentation-konstantin-obenland-on-underscores";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3139:"<p><a href="http://wordpress.tv/" target="_blank">WordPress.tv</a> added its first <a href="http://wordpress.tv/language/german/" target="_blank">German language video</a> today. Konstantin Obenland&#8217;s &#8220;<a href="http://wordpress.tv/2014/07/09/konstantin-obenland-underscores-ein-startertheme-fu%CC%88r-jeden/" target="_blank">Underscores: Ein Startertheme Für Alle</a>&#8221; presentation from WordCamp Hamburg is, surprisingly, the only German video to make it to WordPress.tv so far. Obenland is a code wrangler at Automattic and has also worked extensively with the default WordPress themes. His presentation covers the history and future of <a href="http://underscores.me/" target="_blank">Underscores</a> and its influence on theme development.</p>
<p></p>
<p>The <a href="http://de.slideshare.net/obenland/underscores-de" target="_blank">slides</a> for the presentation are also linked from its listing on WordPress.tv.</p>
<p>If you&#8217;re multilingual, one of the ways you can contribute to WordPress is by <a href="http://blog.wordpress.tv/2013/10/16/caption-and-subtitle/" target="_blank">captioning and subtitling videos</a>. Each video on WordPress.tv has a unique URL labeled &#8220;Subtitle this Video,&#8221; which lets you add subtitles in one of nine available languages. For example, if you click on Obenland&#8217;s video subtitles <a href="http://wordpress.tv/subtitle/?video=36369" target="_blank">link</a>, you&#8217;ll find the guided process for using the tools at <a href="http://www.amara.org/" target="_blank">amara.org</a> to add your subtitles. This is a little-known way that you can contribute to WordPress and help the community share its knowledge across languages.</p>
<p>WordPress.tv doesn&#8217;t appear to have an easy way to search for videos by language, as the search bar isn&#8217;t an effect way of narrowing them down. While guessing at the URLs, I found that WordPress.tv has 61 videos in <a href="http://wordpress.tv/language/japanese/" target="_blank">Japanese</a>, 56 in <a href="http://wordpress.tv/2014/06/20/tony-archambeau-accessibilite-wordpress-creer-des-sites-pour-tous-les-utilisateurs/" target="_blank">French</a>, 38 in <a href="http://wordpress.tv/language/spanish/" target="_blank">Spanish</a>, eight in <a href="http://wordpress.tv/language/russian/" target="_blank">Russian</a>, two in <a href="http://wordpress.tv/language/norwegian/" target="_blank">Norwegian</a>. There are likely many more languages represented there but they&#8217;re not easy to discover.</p>
<p>As the WordPress project is adding major <a href="http://wptavern.com/major-internationalization-improvements-planned-for-wordpress-4-0" target="_blank">internationalization improvements to the 4.0 release</a>, users who are new to the software will have an easier time getting on board. They will be in search for resources to help them get started and learn more. Right now, the vast majority of official WordPress learning resources are in English. In the future it will be exciting to see how the project adapts and changes to accommodate a growing international, multilingual community.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 18:09:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Fri, 18 Jul 2014 05:19:06 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"216048";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Fri, 18 Jul 2014 05:00:13 GMT";s:4:"x-nc";s:11:"HIT lax 249";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130910180210";}', 'no') ; 
INSERT INTO `clooptions` VALUES (165, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1405703949', 'no') ; 
INSERT INTO `clooptions` VALUES (166, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1405660749', 'no') ; 
INSERT INTO `clooptions` VALUES (167, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1405703949', 'no') ; 
INSERT INTO `clooptions` VALUES (168, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Jul 2014 04:59:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32629@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Black Studio TinyMCE Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Nov 2011 15:06:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"31973@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:76:"Adds a WYSIWYG widget based on the standard TinyMCE WordPress visual editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marco Chiesi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"50539@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Displays Google Analytics Reports and Real-Time Statistics in your Dashboard. Automatically inserts the tracking code in every page of your website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 10 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Fri, 18 Jul 2014 05:19:09 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Fri, 18 Jul 2014 05:34:06 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Fri, 18 Jul 2014 04:59:06 +0000";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130910180210";}', 'no') ; 
INSERT INTO `clooptions` VALUES (169, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1405703949', 'no') ; 
INSERT INTO `clooptions` VALUES (170, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1405660749', 'no') ; 
INSERT INTO `clooptions` VALUES (171, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1405703949', 'no') ; 
INSERT INTO `clooptions` VALUES (172, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/\'>WordPress 4.0 Beta 1</a> <span class="rss-date">July 10, 2014</span><div class="rssSummary">WordPress 4.0 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can […]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/themosis-object-oriented-development-framework-for-wordpress-now-in-beta?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=themosis-object-oriented-development-framework-for-wordpress-now-in-beta\' title=\'Themosis is a new object-oriented development framework for WordPress that is currently in beta and set to be released soon. It’s aimed at developers of all skill levels but those with stronger PHP knowledge will have an easier time working with the framework. Themosis was created by Julien Lambé, a Belgium-based application developer. His framework brings a\'>WPTavern: Themosis Object-Oriented Development Framework for WordPress Now in Beta</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/add-avatar-upload-to-buddypress-registration?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=add-avatar-upload-to-buddypress-registration\' title=\'Getting users to upload avatars can be a challenge for BuddyPress communities. Avatars aren’t like profile fields where you can require users to complete them. The problem is that a community without many real-user avatars can be somewhat uninviting. Member directories and widgets end up looking grey and white and uninspiring. Too many default “mystery man”\'>WPTavern: Add Avatar Upload to BuddyPress Registration</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/exploring-the-idea-of-an-internet-archive-specifically-for-wordpress-content?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=exploring-the-idea-of-an-internet-archive-specifically-for-wordpress-content\' title=\'It seems like each time a WordPress podcast disappears, there is one or more to take its place. A few weeks ago, the WP Bacon podcast announced the end of their show to concentrate on other projects. However, a recent search in iTunes for WordPress Podcasts show there is almost an endless amount of content to listen to. Variety of WordPress Podcasts To Liste\'>WPTavern: Exploring The Idea Of An Internet Archive Specifically For WordPress Content</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/google-analytics-dashboard-for-wp/\' class=\'dashboard-news-plugin-link\'>Google Analytics Dashboard for WP</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=google-analytics-dashboard-for-wp&amp;_wpnonce=d6b4f50427&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Google Analytics Dashboard for WP\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `clooptions` VALUES (174, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1405671709', 'yes') ; 
INSERT INTO `clooptions` VALUES (175, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"4463";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2778";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2683";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2196";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2110";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1756";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1553";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1513";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1465";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1449";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1401";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1340";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1308";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1157";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1116";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1096";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"999";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"955";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"955";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"789";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"782";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"781";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"769";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"766";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"703";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"678";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"662";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"651";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"619";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"610";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"592";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"583";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"579";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"579";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"568";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"532";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"525";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"524";}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";s:3:"510";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"507";}}', 'yes') ; 
INSERT INTO `clooptions` VALUES (176, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1405661597;s:7:"checked";a:3:{s:19:"akismet/akismet.php";s:5:"3.0.0";s:9:"hello.php";s:3:"1.6";s:39:"backup-with-restore/backupwordpress.php";s:3:"1.0";}s:8:"response";a:1:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.0.1";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.0.1.zip";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `clooptions` VALUES (177, 'hmbkp_dropbox_settings', 'a:2:{s:7:"enabled";s:2:"no";s:12:"access_token";N;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (178, 'hmbkp_default_path', '/Users/cyponthemic/Desktop/ARTWORKS/WORDPRESS/CLOCHE/wp-content/backupwordpress-e012306e5e-backups', 'yes') ; 
INSERT INTO `clooptions` VALUES (179, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `clooptions` VALUES (180, 'hmbkp_path', '/Users/cyponthemic/Desktop/ARTWORKS/WORDPRESS/CLOCHE/wp-content/backupwordpress-e012306e5e-backups', 'yes') ; 
INSERT INTO `clooptions` VALUES (181, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (182, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `clooptions` VALUES (183, 'hmbkp_plugin_version', '1.0', 'yes') ; 
INSERT INTO `clooptions` VALUES (184, '_transient_timeout_hmbkp_schedule_default-1_filesize', '2811409652', 'no') ; 
INSERT INTO `clooptions` VALUES (185, '_transient_hmbkp_schedule_default-1_filesize', '1392640', 'no') ;
#
# End of data contents of table clooptions
# --------------------------------------------------------

# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocomments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clolinks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clooptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clopostmeta`
# --------------------------------------------------------


#
# Delete any existing table `clopostmeta`
#

DROP TABLE IF EXISTS `clopostmeta`;


#
# Table structure of table `clopostmeta`
#

CREATE TABLE `clopostmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 ;

#
# Data contents of table clopostmeta (71 records)
#
 
INSERT INTO `clopostmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `clopostmeta` VALUES (2, 2, '_edit_lock', '1405585228:1') ; 
INSERT INTO `clopostmeta` VALUES (3, 2, '_edit_last', '1') ; 
INSERT INTO `clopostmeta` VALUES (4, 5, '_edit_last', '1') ; 
INSERT INTO `clopostmeta` VALUES (5, 5, '_edit_lock', '1405585244:1') ; 
INSERT INTO `clopostmeta` VALUES (6, 5, '_wp_page_template', 'default') ; 
INSERT INTO `clopostmeta` VALUES (7, 7, '_edit_last', '1') ; 
INSERT INTO `clopostmeta` VALUES (8, 7, '_wp_page_template', 'default') ; 
INSERT INTO `clopostmeta` VALUES (9, 7, '_edit_lock', '1405585254:1') ; 
INSERT INTO `clopostmeta` VALUES (10, 9, '_edit_last', '1') ; 
INSERT INTO `clopostmeta` VALUES (11, 9, '_wp_page_template', 'default') ; 
INSERT INTO `clopostmeta` VALUES (12, 9, '_edit_lock', '1405585277:1') ; 
INSERT INTO `clopostmeta` VALUES (13, 11, '_edit_last', '1') ; 
INSERT INTO `clopostmeta` VALUES (14, 11, '_wp_page_template', 'default') ; 
INSERT INTO `clopostmeta` VALUES (15, 11, '_edit_lock', '1405585294:1') ; 
INSERT INTO `clopostmeta` VALUES (16, 13, '_menu_item_type', 'post_type') ; 
INSERT INTO `clopostmeta` VALUES (17, 13, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `clopostmeta` VALUES (18, 13, '_menu_item_object_id', '11') ; 
INSERT INTO `clopostmeta` VALUES (19, 13, '_menu_item_object', 'page') ; 
INSERT INTO `clopostmeta` VALUES (20, 13, '_menu_item_target', '') ; 
INSERT INTO `clopostmeta` VALUES (21, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `clopostmeta` VALUES (22, 13, '_menu_item_xfn', '') ; 
INSERT INTO `clopostmeta` VALUES (23, 13, '_menu_item_url', '') ; 
INSERT INTO `clopostmeta` VALUES (25, 14, '_menu_item_type', 'post_type') ; 
INSERT INTO `clopostmeta` VALUES (26, 14, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `clopostmeta` VALUES (27, 14, '_menu_item_object_id', '9') ; 
INSERT INTO `clopostmeta` VALUES (28, 14, '_menu_item_object', 'page') ; 
INSERT INTO `clopostmeta` VALUES (29, 14, '_menu_item_target', '') ; 
INSERT INTO `clopostmeta` VALUES (30, 14, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `clopostmeta` VALUES (31, 14, '_menu_item_xfn', '') ; 
INSERT INTO `clopostmeta` VALUES (32, 14, '_menu_item_url', '') ; 
INSERT INTO `clopostmeta` VALUES (34, 15, '_menu_item_type', 'post_type') ; 
INSERT INTO `clopostmeta` VALUES (35, 15, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `clopostmeta` VALUES (36, 15, '_menu_item_object_id', '7') ; 
INSERT INTO `clopostmeta` VALUES (37, 15, '_menu_item_object', 'page') ; 
INSERT INTO `clopostmeta` VALUES (38, 15, '_menu_item_target', '') ; 
INSERT INTO `clopostmeta` VALUES (39, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `clopostmeta` VALUES (40, 15, '_menu_item_xfn', '') ; 
INSERT INTO `clopostmeta` VALUES (41, 15, '_menu_item_url', '') ; 
INSERT INTO `clopostmeta` VALUES (43, 16, '_menu_item_type', 'post_type') ; 
INSERT INTO `clopostmeta` VALUES (44, 16, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `clopostmeta` VALUES (45, 16, '_menu_item_object_id', '5') ; 
INSERT INTO `clopostmeta` VALUES (46, 16, '_menu_item_object', 'page') ; 
INSERT INTO `clopostmeta` VALUES (47, 16, '_menu_item_target', '') ; 
INSERT INTO `clopostmeta` VALUES (48, 16, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `clopostmeta` VALUES (49, 16, '_menu_item_xfn', '') ; 
INSERT INTO `clopostmeta` VALUES (50, 16, '_menu_item_url', '') ; 
INSERT INTO `clopostmeta` VALUES (52, 17, '_menu_item_type', 'post_type') ; 
INSERT INTO `clopostmeta` VALUES (53, 17, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `clopostmeta` VALUES (54, 17, '_menu_item_object_id', '2') ; 
INSERT INTO `clopostmeta` VALUES (55, 17, '_menu_item_object', 'page') ; 
INSERT INTO `clopostmeta` VALUES (56, 17, '_menu_item_target', '') ; 
INSERT INTO `clopostmeta` VALUES (57, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `clopostmeta` VALUES (58, 17, '_menu_item_xfn', '') ; 
INSERT INTO `clopostmeta` VALUES (59, 17, '_menu_item_url', '') ; 
INSERT INTO `clopostmeta` VALUES (60, 18, '_edit_last', '1') ; 
INSERT INTO `clopostmeta` VALUES (61, 18, '_edit_lock', '1405660668:1') ; 
INSERT INTO `clopostmeta` VALUES (62, 19, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-1_01.png') ; 
INSERT INTO `clopostmeta` VALUES (63, 19, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:766;s:4:"file";s:39:"2014/07/Flexbox-Code-Challenge-1_01.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_01-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_01-156x300.png";s:5:"width";i:156;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `clopostmeta` VALUES (64, 20, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-1_02.png') ; 
INSERT INTO `clopostmeta` VALUES (65, 20, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:58;s:4:"file";s:39:"2014/07/Flexbox-Code-Challenge-1_02.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:38:"Flexbox-Code-Challenge-1_02-150x58.png";s:5:"width";i:150;s:6:"height";i:58;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:38:"Flexbox-Code-Challenge-1_02-300x43.png";s:5:"width";i:300;s:6:"height";i:43;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `clopostmeta` VALUES (66, 21, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-1_03.png') ; 
INSERT INTO `clopostmeta` VALUES (67, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:1054;s:4:"file";s:39:"2014/07/Flexbox-Code-Challenge-1_03.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_03-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_03-113x300.png";s:5:"width";i:113;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:40:"Flexbox-Code-Challenge-1_03-388x1024.png";s:5:"width";i:388;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `clopostmeta` VALUES (68, 22, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-1_04.png') ; 
INSERT INTO `clopostmeta` VALUES (69, 22, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:1050;s:4:"file";s:39:"2014/07/Flexbox-Code-Challenge-1_04.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_04-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_04-114x300.png";s:5:"width";i:114;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:40:"Flexbox-Code-Challenge-1_04-390x1024.png";s:5:"width";i:390;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `clopostmeta` VALUES (70, 23, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-1_05.png') ; 
INSERT INTO `clopostmeta` VALUES (71, 23, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:1214;s:4:"file";s:39:"2014/07/Flexbox-Code-Challenge-1_05.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_05-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:38:"Flexbox-Code-Challenge-1_05-98x300.png";s:5:"width";i:98;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:40:"Flexbox-Code-Challenge-1_05-337x1024.png";s:5:"width";i:337;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `clopostmeta` VALUES (72, 24, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-1_06.png') ; 
INSERT INTO `clopostmeta` VALUES (73, 24, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:716;s:4:"file";s:39:"2014/07/Flexbox-Code-Challenge-1_06.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_06-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_06-167x300.png";s:5:"width";i:167;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `clopostmeta` VALUES (74, 25, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-1_07.png') ; 
INSERT INTO `clopostmeta` VALUES (75, 25, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:938;s:4:"file";s:39:"2014/07/Flexbox-Code-Challenge-1_07.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_07-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:39:"Flexbox-Code-Challenge-1_07-127x300.png";s:5:"width";i:127;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ;
#
# End of data contents of table clopostmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocomments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clolinks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clooptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clopostmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloposts`
# --------------------------------------------------------


#
# Delete any existing table `cloposts`
#

DROP TABLE IF EXISTS `cloposts`;


#
# Table structure of table `cloposts`
#

CREATE TABLE `cloposts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 ;

#
# Data contents of table cloposts (26 records)
#
 
INSERT INTO `cloposts` VALUES (1, 1, '2014-07-17 02:28:19', '2014-07-17 02:28:19', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-07-17 02:28:19', '2014-07-17 02:28:19', '', 0, 'http://localhost:8888/CLOCHE/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `cloposts` VALUES (2, 1, '2014-07-17 02:28:19', '2014-07-17 02:28:19', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href="http://localhost:8888/CLOCHE/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Home', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-07-17 08:22:49', '2014-07-17 08:22:49', '', 0, 'http://localhost:8888/CLOCHE/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `cloposts` VALUES (3, 1, '2014-07-17 08:00:55', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-07-17 08:00:55', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/CLOCHE/?p=3', 0, 'post', '', 0) ; 
INSERT INTO `cloposts` VALUES (4, 1, '2014-07-17 08:22:49', '2014-07-17 08:22:49', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href="http://localhost:8888/CLOCHE/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Home', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-07-17 08:22:49', '2014-07-17 08:22:49', '', 2, 'http://localhost:8888/CLOCHE/2-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `cloposts` VALUES (5, 1, '2014-07-17 08:23:07', '2014-07-17 08:23:07', '', 'Blog', '', 'publish', 'open', 'open', '', 'blog', '', '', '2014-07-17 08:23:07', '2014-07-17 08:23:07', '', 0, 'http://localhost:8888/CLOCHE/?page_id=5', 0, 'page', '', 0) ; 
INSERT INTO `cloposts` VALUES (6, 1, '2014-07-17 08:23:07', '2014-07-17 08:23:07', '', 'Blog', '', 'inherit', 'open', 'open', '', '5-revision-v1', '', '', '2014-07-17 08:23:07', '2014-07-17 08:23:07', '', 5, 'http://localhost:8888/CLOCHE/5-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `cloposts` VALUES (7, 1, '2014-07-17 08:23:17', '2014-07-17 08:23:17', '', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2014-07-17 08:23:17', '2014-07-17 08:23:17', '', 0, 'http://localhost:8888/CLOCHE/?page_id=7', 0, 'page', '', 0) ; 
INSERT INTO `cloposts` VALUES (8, 1, '2014-07-17 08:23:17', '2014-07-17 08:23:17', '', 'About', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-07-17 08:23:17', '2014-07-17 08:23:17', '', 7, 'http://localhost:8888/CLOCHE/7-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `cloposts` VALUES (9, 1, '2014-07-17 08:23:38', '2014-07-17 08:23:38', '', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2014-07-17 08:23:38', '2014-07-17 08:23:38', '', 0, 'http://localhost:8888/CLOCHE/?page_id=9', 0, 'page', '', 0) ; 
INSERT INTO `cloposts` VALUES (10, 1, '2014-07-17 08:23:38', '2014-07-17 08:23:38', '', 'Contact', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2014-07-17 08:23:38', '2014-07-17 08:23:38', '', 9, 'http://localhost:8888/CLOCHE/9-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `cloposts` VALUES (11, 1, '2014-07-17 08:23:53', '2014-07-17 08:23:53', '', 'Cloches', '', 'publish', 'open', 'open', '', 'cloches', '', '', '2014-07-17 08:23:53', '2014-07-17 08:23:53', '', 0, 'http://localhost:8888/CLOCHE/?page_id=11', 0, 'page', '', 0) ; 
INSERT INTO `cloposts` VALUES (12, 1, '2014-07-17 08:23:53', '2014-07-17 08:23:53', '', 'Cloches', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-07-17 08:23:53', '2014-07-17 08:23:53', '', 11, 'http://localhost:8888/CLOCHE/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `cloposts` VALUES (13, 1, '2014-07-17 08:24:31', '2014-07-17 08:24:31', ' ', '', '', 'publish', 'open', 'open', '', '13', '', '', '2014-07-17 08:24:31', '2014-07-17 08:24:31', '', 0, 'http://localhost:8888/CLOCHE/?p=13', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `cloposts` VALUES (14, 1, '2014-07-17 08:24:31', '2014-07-17 08:24:31', ' ', '', '', 'publish', 'open', 'open', '', '14', '', '', '2014-07-17 08:24:31', '2014-07-17 08:24:31', '', 0, 'http://localhost:8888/CLOCHE/?p=14', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `cloposts` VALUES (15, 1, '2014-07-17 08:24:31', '2014-07-17 08:24:31', ' ', '', '', 'publish', 'open', 'open', '', '15', '', '', '2014-07-17 08:24:31', '2014-07-17 08:24:31', '', 0, 'http://localhost:8888/CLOCHE/?p=15', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `cloposts` VALUES (16, 1, '2014-07-17 08:24:31', '2014-07-17 08:24:31', ' ', '', '', 'publish', 'open', 'open', '', '16', '', '', '2014-07-17 08:24:31', '2014-07-17 08:24:31', '', 0, 'http://localhost:8888/CLOCHE/?p=16', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `cloposts` VALUES (17, 1, '2014-07-17 08:24:31', '2014-07-17 08:24:31', ' ', '', '', 'publish', 'open', 'open', '', '17', '', '', '2014-07-17 08:24:31', '2014-07-17 08:24:31', '', 0, 'http://localhost:8888/CLOCHE/?p=17', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `cloposts` VALUES (18, 1, '2014-07-18 05:20:08', '2014-07-18 05:20:08', '<a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_01.png"><img class="alignnone size-medium wp-image-19" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_01-156x300.png" alt="Flexbox---Code-Challenge-(1)_01" width="156" height="300" /></a>  <a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_03.png"><img class="alignnone size-medium wp-image-21" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_03-113x300.png" alt="Flexbox---Code-Challenge-(1)_03" width="113" height="300" /></a> <a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_04.png"><img class="alignnone size-medium wp-image-22" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_04-114x300.png" alt="Flexbox---Code-Challenge-(1)_04" width="114" height="300" /></a> <a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_05.png"><img class="alignnone size-medium wp-image-23" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_05-98x300.png" alt="Flexbox---Code-Challenge-(1)_05" width="98" height="300" /></a> <a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_06.png"><img class="alignnone size-medium wp-image-24" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_06-167x300.png" alt="Flexbox---Code-Challenge-(1)_06" width="167" height="300" /></a> <a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_07.png"><img class="alignnone size-medium wp-image-25" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_07-127x300.png" alt="Flexbox---Code-Challenge-(1)_07" width="127" height="300" /></a>', '', '', 'publish', 'open', 'open', '', '18', '', '', '2014-07-18 05:20:08', '2014-07-18 05:20:08', '', 0, 'http://localhost:8888/CLOCHE/?p=18', 0, 'post', '', 0) ; 
INSERT INTO `cloposts` VALUES (19, 1, '2014-07-18 05:19:51', '2014-07-18 05:19:51', '', 'Flexbox---Code-Challenge-(1)_01', '', 'inherit', 'open', 'open', '', 'flexbox-code-challenge-1_01', '', '', '2014-07-18 05:19:51', '2014-07-18 05:19:51', '', 18, 'http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_01.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `cloposts` VALUES (20, 1, '2014-07-18 05:19:52', '2014-07-18 05:19:52', '', 'Flexbox---Code-Challenge-(1)_02', '', 'inherit', 'open', 'open', '', 'flexbox-code-challenge-1_02', '', '', '2014-07-18 05:19:52', '2014-07-18 05:19:52', '', 18, 'http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_02.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `cloposts` VALUES (21, 1, '2014-07-18 05:19:52', '2014-07-18 05:19:52', '', 'Flexbox---Code-Challenge-(1)_03', '', 'inherit', 'open', 'open', '', 'flexbox-code-challenge-1_03', '', '', '2014-07-18 05:19:52', '2014-07-18 05:19:52', '', 18, 'http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_03.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `cloposts` VALUES (22, 1, '2014-07-18 05:19:53', '2014-07-18 05:19:53', '', 'Flexbox---Code-Challenge-(1)_04', '', 'inherit', 'open', 'open', '', 'flexbox-code-challenge-1_04', '', '', '2014-07-18 05:19:53', '2014-07-18 05:19:53', '', 18, 'http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_04.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `cloposts` VALUES (23, 1, '2014-07-18 05:19:54', '2014-07-18 05:19:54', '', 'Flexbox---Code-Challenge-(1)_05', '', 'inherit', 'open', 'open', '', 'flexbox-code-challenge-1_05', '', '', '2014-07-18 05:19:54', '2014-07-18 05:19:54', '', 18, 'http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_05.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `cloposts` VALUES (24, 1, '2014-07-18 05:19:55', '2014-07-18 05:19:55', '', 'Flexbox---Code-Challenge-(1)_06', '', 'inherit', 'open', 'open', '', 'flexbox-code-challenge-1_06', '', '', '2014-07-18 05:19:55', '2014-07-18 05:19:55', '', 18, 'http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_06.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `cloposts` VALUES (25, 1, '2014-07-18 05:19:56', '2014-07-18 05:19:56', '', 'Flexbox---Code-Challenge-(1)_07', '', 'inherit', 'open', 'open', '', 'flexbox-code-challenge-1_07', '', '', '2014-07-18 05:19:56', '2014-07-18 05:19:56', '', 18, 'http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_07.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `cloposts` VALUES (26, 1, '2014-07-18 05:20:08', '2014-07-18 05:20:08', '<a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_01.png"><img class="alignnone size-medium wp-image-19" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_01-156x300.png" alt="Flexbox---Code-Challenge-(1)_01" width="156" height="300" /></a>  <a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_03.png"><img class="alignnone size-medium wp-image-21" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_03-113x300.png" alt="Flexbox---Code-Challenge-(1)_03" width="113" height="300" /></a> <a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_04.png"><img class="alignnone size-medium wp-image-22" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_04-114x300.png" alt="Flexbox---Code-Challenge-(1)_04" width="114" height="300" /></a> <a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_05.png"><img class="alignnone size-medium wp-image-23" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_05-98x300.png" alt="Flexbox---Code-Challenge-(1)_05" width="98" height="300" /></a> <a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_06.png"><img class="alignnone size-medium wp-image-24" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_06-167x300.png" alt="Flexbox---Code-Challenge-(1)_06" width="167" height="300" /></a> <a href="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_07.png"><img class="alignnone size-medium wp-image-25" src="http://localhost:8888/CLOCHE/wp-content/uploads/2014/07/Flexbox-Code-Challenge-1_07-127x300.png" alt="Flexbox---Code-Challenge-(1)_07" width="127" height="300" /></a>', '', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2014-07-18 05:20:08', '2014-07-18 05:20:08', '', 18, 'http://localhost:8888/CLOCHE/18-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table cloposts
# --------------------------------------------------------

# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocomments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clolinks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clooptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clopostmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloposts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterm_relationships`
# --------------------------------------------------------


#
# Delete any existing table `cloterm_relationships`
#

DROP TABLE IF EXISTS `cloterm_relationships`;


#
# Table structure of table `cloterm_relationships`
#

CREATE TABLE `cloterm_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table cloterm_relationships (8 records)
#
 
INSERT INTO `cloterm_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `cloterm_relationships` VALUES (13, 2, 0) ; 
INSERT INTO `cloterm_relationships` VALUES (14, 2, 0) ; 
INSERT INTO `cloterm_relationships` VALUES (15, 2, 0) ; 
INSERT INTO `cloterm_relationships` VALUES (16, 2, 0) ; 
INSERT INTO `cloterm_relationships` VALUES (17, 2, 0) ; 
INSERT INTO `cloterm_relationships` VALUES (18, 1, 0) ; 
INSERT INTO `cloterm_relationships` VALUES (18, 3, 0) ;
#
# End of data contents of table cloterm_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocomments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clolinks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clooptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clopostmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloposts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterm_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterm_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `cloterm_taxonomy`
#

DROP TABLE IF EXISTS `cloterm_taxonomy`;


#
# Table structure of table `cloterm_taxonomy`
#

CREATE TABLE `cloterm_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table cloterm_taxonomy (3 records)
#
 
INSERT INTO `cloterm_taxonomy` VALUES (1, 1, 'category', '', 0, 2) ; 
INSERT INTO `cloterm_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 5) ; 
INSERT INTO `cloterm_taxonomy` VALUES (3, 3, 'post_format', '', 0, 1) ;
#
# End of data contents of table cloterm_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocomments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clolinks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clooptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clopostmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloposts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterm_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterm_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterms`
# --------------------------------------------------------


#
# Delete any existing table `cloterms`
#

DROP TABLE IF EXISTS `cloterms`;


#
# Table structure of table `cloterms`
#

CREATE TABLE `cloterms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table cloterms (3 records)
#
 
INSERT INTO `cloterms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `cloterms` VALUES (2, 'Main menu', 'main-menu', 0) ; 
INSERT INTO `cloterms` VALUES (3, 'post-format-image', 'post-format-image', 0) ;
#
# End of data contents of table cloterms
# --------------------------------------------------------

# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocomments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clolinks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clooptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clopostmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloposts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterm_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterm_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clousermeta`
# --------------------------------------------------------


#
# Delete any existing table `clousermeta`
#

DROP TABLE IF EXISTS `clousermeta`;


#
# Table structure of table `clousermeta`
#

CREATE TABLE `clousermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ;

#
# Data contents of table clousermeta (18 records)
#
 
INSERT INTO `clousermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `clousermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `clousermeta` VALUES (3, 1, 'nickname', 'clocheMaster') ; 
INSERT INTO `clousermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `clousermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `clousermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `clousermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `clousermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `clousermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `clousermeta` VALUES (10, 1, 'clocapabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `clousermeta` VALUES (11, 1, 'clouser_level', '10') ; 
INSERT INTO `clousermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `clousermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `clousermeta` VALUES (14, 1, 'clodashboard_quick_press_last_post_id', '3') ; 
INSERT INTO `clousermeta` VALUES (15, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `clousermeta` VALUES (16, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:8:"add-post";i:1;s:9:"add-orbit";i:2;s:12:"add-post_tag";i:3;s:15:"add-post_format";}') ; 
INSERT INTO `clousermeta` VALUES (17, 1, 'clouser-settings', 'libraryContent=browse') ; 
INSERT INTO `clousermeta` VALUES (18, 1, 'clouser-settings-time', '1405660804') ;
#
# End of data contents of table clousermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/CLOCHE MySQL database backup
#
# Generated: Friday 18. July 2014 05:33 UTC
# Hostname: localhost
# Database: `cloche`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocommentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clocomments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clolinks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clooptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clopostmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloposts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterm_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterm_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `cloterms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clousermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `clousers`
# --------------------------------------------------------


#
# Delete any existing table `clousers`
#

DROP TABLE IF EXISTS `clousers`;


#
# Table structure of table `clousers`
#

CREATE TABLE `clousers` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table clousers (1 records)
#
 
INSERT INTO `clousers` VALUES (1, 'clocheMaster', '$P$BQWkjGVxVRPBJumzSxfm2.rRXAgD3T.', 'clochemaster', 'alex.chavet@gmail.com', '', '2014-07-17 02:28:19', '', 0, 'clocheMaster') ;
#
# End of data contents of table clousers
# --------------------------------------------------------

